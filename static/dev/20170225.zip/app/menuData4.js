menuData = 
{
  categories: [
    ["Bag | 手袋"],
    ["Watch | 钟表"]
    //"Others"
  ],
  bstyle: [
    ["Shoulder Bags | 肩背包"], 
    ["Wallets and Small Accessories | 钱包及配件"], 
    ["Clutches | 手包"], 
    ["Totes | 手提包"], 
    ["Backpacks | 背包"], 
    ["Briefcases | 公文包"], 
    //["Others 其他"], 
    //["Wrist Watches/ 腕表"], 
    ["Luggage and Travelling bags | 旅行包及行李箱"], 
    //["Wallets and small items/ 钱包及饰物"]
  ],
  bbrand: [
    ["Balenciaga", "Balenciaga"],
    ["Bottega veneta","宝缇嘉"],
    ["Bulgari","宝格丽"],
    ["Celine","赛琳"],
    ["Chanel","香奈儿"],
    ["Chloe","蔻依"],
    ["Christian Dior","Christian Dior"],
    ["Coach","Coach"],
    ["Fendi","芬迪"],
    ["Givenchy","Givenchy"],
    ["Gucci","古驰"],
    ["Hermes","爱马仕"],
    ["Louis vuitton","路易威登"],
    ["Michael kors","迈克 科尔斯"],
    ["Miu Miu","Miu Miu"],
    ["Prada","普拉达"],
    ["Salvatore ferragamo","Salvatore ferragamo"],
    ["Tiffany & co.","蒂芙尼"],
    ["Tory brunch","Tory brunch"],
    ["Valentino","华伦天奴"],
    ["Yves saint laurent","Yves saint laurent"]
  ],
  wbrand: [
    ["Audemars piguet","爱彼"],
    ["Breitling","百年灵"],
    ["Cartier","卡地亚"],
    ["Franck muller","法穆兰"],
    ["IWC","万国"],
    ["Jeager","Jeager"],
    ["Omega","欧米茄"],
    ["Panerai","沛纳海"],
    ["Patek Philippe","百达翡丽"],
    ["Rolex","劳力士"],
    ["Tissot","天梭"]
  ],
  colour: [
    ["White","白色"],
    ["Black","黑色"],
    ["Brown","褐色"],
    ["Orange","橙色"],
    ["Red","红色"],
    ["Green","绿色"],
    ["Yellow","黄色"],
    ["Blue","蓝色"]
  ],

}
//###############################################################################
var brandid = [["1276","0","hermes","爱马仕"]
//,["1277","0","gianni versace","凡赛斯"]
,["1279","0","prada","普拉达"],["1280","0","chanel","香奈儿"],["1281","0","louis vuitton","路易威登"],["1282","0","bottega veneta","宝缇嘉"],["1284","0","fendi","芬迪"]
//,["1287","0","paloma picasso","毕卡索"]
,["1288","0","celine","赛琳"]
// ,["1289","0","saks fifth avenue","萨克斯第五大道"]
//,["1290","0","judith leiber","珠迪丝·雷伯"]
,["1293","0","valentino","华伦天奴"],["1297","0","chloe","蔻依"]
//,["1298","0","dolce & gabbana","杜嘉班纳"]
//,["1301","0","burberry","博伯利"]
//,["1302","0","lulu guinness","露露·吉尼斯"]
//,["1304","0","escada","爱思卡达"]
// ,["1307","0","pierre cardin","皮尔·卡丹"]
//,["1308","0","jil sander","吉尔·桑达"]
// ,["1314","0","viktor & rolf","维果罗夫"]
// ,["1315","0","mulberry","玛百莉"]
// ,["1318","0","tiffany & co.","蒂芙尼"]
//,["1321","0","calvin klein","卡尔文·克雷恩"]
// ,["1322","0","yohji yamamoto","山本耀司"]
,["1323","0","rolex","劳力士"],["1324","0","panerai","沛纳海"],["1326","0","patek philippe","百达翡丽"],["1327","0","audemars piguet","爱彼"]
//,["1328","0","breguet","宝玑"]
// ,["1329","0","vacheron constantin","江诗丹顿"]
,["1330","0","omega","欧米茄"]
// ,["1332","0","tudor","帝舵"]
,["1333","0","cartier","卡地亚"],["1334","0","iwc","万国"]
// ,["1337","0","piaget","伯爵"]
//,["1338","0","chronoswiss","瑞宝"]
,["1339","0","franck muller","法穆兰"]
// ,["1340","0","maurice lacroix","艾美"]
//,["1342","0","girard perregaux","芝柏"]
// ,["1343","0","roger dubuis","罗杰杜彼"]
//,["1345","0","breitling","百年灵"]
// ,["1349","0","zenith","真力时"]
,["1352","0","bulgari","宝格丽"]
//,["1356","0","longines","浪琴"]
//,["1357","0","chopard","萧邦"]
//,["1361","0","movado","摩凡陀"]
,["1363","0","tissot","天梭"],["1364","0","michael kors","迈克 科尔斯"]
//,["1365","0","armani","阿玛尼"]
,["1371","0","gucci","古驰"]
//,["1396","0","harry winston","哈利温斯顿"]
// ,["1399","0","raymond weil","蕾蒙威"]
//,["1405","0","hamilton","汉米尔顿"]
// ,["1407","0","ulysse nardin","雅典"]
//,["1409","0","baume & mercier","名士"]
//,["1412","0","elgin","度"]
//,["1413","0","concord","君皇"]
//,["1421","0","heuer","豪雅"]
//,["1426","0","ebel","玉宝"]
// ,["1432","0","versace","范思哲"]
// ,["1434","0","montblanc","万宝龙"]
//,["1444","0","carl f. bucherer","宝齐莱"]
//,["1446","0","de grisogono","德高娜"]
//,["1460","0","bucherer","宝齐莱"]
//,["1462","0","boucheron","宝诗龙"]
//,["1465","0","bulova","宝路华"]
//,["1483","0","david yurman","大卫·雅曼"]
//,["1494","0","glycine","冠星表"]
//,["1733","0","balmain","宝曼"]
//,["11233","0","blancpain","宝珀"]
,["11234","0","designer brands","设计师品牌"]
//,["11235","0","corum","昆仑"]
//,["11236","0","glashutte","格拉苏蒂"]
,["11237","0","balenciaga","巴黎世家"],["11238","0","yves saint laurent","圣罗兰"]
// ,["11239","0","stella mccartney","斯特拉·麦卡特尼 "]
,["11240","0","miu miu","缪缪"],["11241","0","givenchy","纪梵希"]
// ,["11242","0","delvaux","delvaux"]
,["11243","0","christian dior","克丽斯汀·迪奥"]
//,["11244","0","marc jacobs","马克·雅可布"]
//,["11245","0","mcm","mcm"]
,["11246","0","jaeger","积家"],["11247","0","salvatore ferragamo","菲拉格慕"]
// ,["11248","0","loewe","罗意威"]
//,["11249","0","marc by marc jacobs","马克·雅可布之马克"]
,["11250","0","coach","蔻驰"]
// ,["11251","0","selection","selection"]
,["11252","0","tiffany & co","蒂芙尼"]
// ,["11253","0","tod's","tod's"]
//,["11254","0","kate spade","凯特·丝蓓"]
// ,["11255","0","ralph lauren","拉尔夫·劳伦"]
//,["11256","0","bedat","贝达"]
//,["11257","0","jimmy choo","周仰杰"]
// ,["11258","0","seiko","精工"]
//,["11259","0","bally","巴利"]
//,["11260","0","emilio pucci","璞琪"]
//,["11261","0","furla","芙拉 "]
// ,["11262","0","van cleef & arpels","梵克雅宝"]
//,["11263","0","moschino","莫斯奇诺"]
,["11264","0","tory burch","汤丽柏琦"]
//,["11265","0","lanvin","浪凡"]
//,["11266","0","goyard","goyard"]
//,["11268","0","giorgio armani","阿玛尼"]
// ,["11269","0","mcqueen","麦昆"]
//,["11270","0","longchamp","珑骧"]
//,["11271","0","hugo boss","hugo boss"]
// ,["11272","0","tumi","途明"]
//,["11273","0","ermanno scervino","ermanno scervino"]
//,["11274","0","christian louboutin","克里斯提·鲁布托"]
//["11275","0","a. lange & sohne","朗格"]
//,["11276","0","alexander wang","亚历山大·王"]
//,["11277","0","bell & ross","柏莱士"]
//,["11278","0","hublot","宇舶"]
//,["11279","0","moncler","moncler"]
// ,["11280","0","proenza schouler","proenza schouler"]
// ,["11281","0","stefano ricci","史蒂芬劳.尼治"]
// ,["11282","0","tom ford","汤姆·福特"]
//,["11283","0","anya hindmarch","安雅·希德玛芝"]
// ,["11284","0","prada small","prada small"]
//,["11285","0","kenzo","高田贤三"]
//,["11286","0","lancaster","lancaster"]
//,["11287","0","karl lagerfeld","卡尔·拉格斐"]
//,["11288","0","b","b"]
//,["11289","0","les petits joueurs","les petits joueurs"]
//,["11290","0","issey miyake","三宅一生"]
// ,["11291","0","notes","notes"]
//,["11292","0","escale plage","escale plage"]
//,["11293","0","jige","jige"]
//,["11294","0","double sens","double sens"]
// ,["11295","0","valentino card","valentino card"]
// ,["11296","0","red valentino","red valentino"]
//,["11297","0","diesel","迪赛尔"]
//,["11298","0","emporio armani","安普里奥·阿玛尼"]
// ,["11299","0","universal geneve","universal geneve"]
//,["11300","0","lecoultre","lecoultre"]
// ,["11301","0","shreve & co","shreve & co"]
//,["11302","0","gubelin","固宝琳"]
//,["11303","0","baume et mercier","名士"]
// ,["11304","0","parmigiani","帕玛强尼"]
//,["11305","0","bueche girod","bueche girod"]
//,["11306","0","j.e. caldwell","j.e. caldwell"]
//,["11307","0","eberhard","依百克"]
//,["11308","0","kieselstein-cord","kieselstein-cord"]
//,["11309","0","glycine watch co.","glycine watch co."]
//,["11310","0","mathey tissot","天梭"]
//,["11311","0","gruen","高路云"]
// ,["11312","0","roberta di camerino","诺贝达"]
//,["11313","0","carlos falchi","carlos falchi"]
// ,["11314","0","timmy woods","timmy woods"]
//,["11315","0","lambertson truex","lambertson truex"]
// ,["11316","0","nancy gonzalez","南希·冈萨雷斯"]
//,["11317","0","charles jourdan","charles jourdan"]
// ,["11318","0","rodo","rodo"]
// ,["11319","0","whiting & davis","whiting & davis"]
//,["11320","0","courreges","活希源"]
//,["11321","0","holzman","holzman"]
//,["11322","0","jean paul","高缇耶"]
//,["11323","0","coblentz","coblentz"]
//,["11324","0","harry rosenfeld","harry rosenfeld"]
//,["11325","0","koret","koret"]
//,["11326","0","bellestones","bellestones"]
// ,["11327","0","walborg","walborg"]
// ,["11328","0","paco rabanne","帕高"]
//,["11329","0","giorgio's palm beach","giorgio's palm beach"]
//,["11330","0","braccialini","布奇里尼"]
// ,["11331","0","nina ricci","莲娜丽姿"]
//,["11332","0","etro","艾特罗"]
// ,["11333","0","zagliani","zagliani"]
//,["11334","0","delill","delill"]
//,["11335","0","morabito","morabito"]
// ,["11336","0","vbh","vbh"]
//,["11337","0","jacomo","jacomo"]
// ,["11338","0","tyrolean","tyrolean"]
// ,["11339","0","susan bennis and warren edwards","susan bennis and warren edwards"]
//,["11340","0","fleurette of miami","fleurette of miami"]
//,["11341","0","coppolo e topo","coppolo e topo"]
//,["11342","0","diane von furstenberg","diane von furstenberg"]
]


//################################################################################
var collectionid = [["16780","0","balenciaga city"," 巴黎世家 City"],["16785","0","balenciaga day"," 巴黎世家 Day"],["16784","0","balenciaga first"," 巴黎世家 First"],["16777","0","balenciaga le dix soft"," 巴黎世家 Le Dix Soft"],["16758","0","balenciaga part time"," 巴黎世家 Part Time"],["16803","0","balenciaga town"," 巴黎世家 Town"],["17849","0","balenciaga traveler"," 巴黎世家 Traveler"],["16823","0","balenciaga weekender"," 巴黎世家 weekender"],["16738","0","balenciaga work"," 巴黎世家 work"],["16806","0","celine belt","思琳/赛琳 鲶鱼包"],["16745","0","celine cabas","思琳/赛琳 购物(袋)包"],["16849","0","celine classic box","思琳/赛琳 方形复古包"],["16763","0","celine luggage","思琳/赛琳 笑脸包"],["16801","0","celine phantom","思琳/赛琳 幻影包"],["16791","0","celine ring","思琳/赛琳 Ring "],["16826","0","celine tie","思琳/赛琳 Tie"],["16762","0","celine trapeze","思琳/赛琳 秋千包"],["16808","0","celine trio","思琳/赛琳 三层挎包"],["16729","0","chanel boy quilted flap","香奈儿 Le Boy"],["16794","0","chanel cerf tote","香奈儿妈咪包"],["16730","0","chanel classic flap","香奈儿CF"],["16739","0","chanel gst","香奈儿GST"],["16835","0","chanel medallion tote","香奈儿图案手提包"],["16813","0","chanel pst","香奈儿PST"],["17851","0","chanel ptt","香奈儿PTT"],["16724","0","chanel reissue","香奈儿 2.55 Reissue"],["16881","0","chanel timeless clutch","香奈儿手拿包"],["16843","0","chloe drew","蔻依 小猪包"],["16854","0","chloe elsie","蔻依 Elsie"],["16853","0","chloe faye","蔻依 Faye"],["16869","0","chloe hudson","蔻依 Hudson"],["16878","0","chloe kurtis","蔻依 Kurtis"],["16908","0","chloe lexa","蔻依 Lexa"],["16809","0","chloe marcie","蔻依 Marcie"],["16907","0","chloe milo","蔻依 购物包"],["18215","0","chloe mily","蔻依 小方包"],["16737","0","chloe paraty","蔻依 Paraty"],["16771","0","fendi 2 jours","芬迪 2 jours"],["18141","0","fendi 2jours","芬迪 2 jours"],["17848","0","fendi 3 jours","芬迪 3 jours"],["16811","0","fendi baguette","芬迪 法棍包"],["16782","0","fendi by the way","芬迪 By The Way"],["16870","0","fendi dotcom","芬迪 Dotcom"],["16812","0","fendi peekaboo","芬迪躲猫猫包"],["16820","0","hermes atlas","爱马仕 Atlas"],["16742","0","hermes azap","爱马仕 Azap"],["16741","0","hermes bearn","爱马仕 Bearn"],["16759","0","hermes berline","爱马仕 Berline"],["16725","0","hermes birkin","爱马仕 铂金包"],["16760","0","hermes bolide","爱马仕 保龄球包"],["16768","0","hermes cabag","爱马仕 Cabag"],["16746","0","hermes constance","爱马仕 康斯坦斯包"],["16822","0","hermes convoyeur","爱马仕 Convoyeur"],["16740","0","hermes dogon","爱马仕 Dogon"],["16765","0","hermes double sens","爱马仕 Double sens"],["16814","0","hermes egee","爱马仕 Egee"],["16816","0","hermes envelope","爱马仕 Envelope"],["16734","0","hermes evelyne","爱马仕 伊芙琳包"],["16770","0","hermes faco","爱马仕 Faco"],["16744","0","hermes garden party","爱马仕 花园派对包"],["16882","0","hermes garden shoulder","爱马仕 garden shoulder"],["16832","0","hermes hac","爱马仕 Hac"],["16825","0","hermes halzan","爱马仕 Halzan"],["16864","0","hermes harnais","爱马仕 Harnais"],["16747","0","hermes herbag","爱马仕 Herbag"],["16883","0","hermes hermail tutti-frutti","爱马仕 水果包"],["16817","0","hermes jige","爱马仕 Jige"],["16727","0","hermes jypsiere","爱马仕 吉普赛包"],["16732","0","hermes kelly","爱马仕 凯莉包"],["16731","0","hermes lindy","爱马仕 林迪包"],["17855","0","hermes massai","爱马仕 Massai"],["16818","0","hermes medor","爱马仕 Medor"],["18216","0","hermes oxer","爱马仕 Oxer"],["16755","0","hermes picotin","爱马仕 菜篮子包/水桶包/锁头包"],["16788","0","hermes plume","爱马仕 Plume"],["16862","0","hermes remix","爱马仕 Remix"],["16859","0","hermes roulis","爱马仕 Roulis"],["16748","0","hermes sac a depeche","爱马仕 Sac a depeche"],["16778","0","hermes toolbox","爱马仕 Toolbox"],["16751","0","hermes victoria","爱马仕 维多利亚包"],["16906","0","hermes virevolte","爱马仕 Virevolte"],["16752","0","louis vuitton alma","LV 贝壳包"],["16837","0","louis vuitton ana","LV Ana"],["16863","0","louis vuitton artsy","LV Artsy"],["16750","0","louis vuitton babylone","LV Babylone"],["16838","0","louis vuitton bagatelle","LV Bagatelle"],["16903","0","louis vuitton berri","LV Berri"],["16897","0","louis vuitton bloomsbury","LV Bloomsbury"],["16772","0","louis vuitton brea","LV Brea"],["16902","0","louis vuitton brompton","LV Brompton"],["16857","0","louis vuitton caissa","LV Caissa"],["16810","0","louis vuitton calvi","LV Calvi"],["16776","0","louis vuitton capucines","LV Capucines"],["16792","0","louis vuitton chain louise","LV Chain Louise"],["16833","0","louis vuitton city steamer ","LV City Steamer"],["16828","0","louis vuitton cluny","LV Cluny"],["16726","0","louis vuitton croisette","LV 邮差包"],["17852","0","louis vuitton deesse","LV Deesse"],["16790","0","louis vuitton delightful","LV Delightful"],["16774","0","louis vuitton doc","LV Doc"],["16798","0","louis vuitton dora","LV Dora"],["16887","0","louis vuitton duomo","LV Duomo"],["16851","0","louis vuitton estrela","LV Estrela"],["16749","0","louis vuitton eva","LV Eva"],["17736","0","louis vuitton explorer bag","LV Explorer"],["16844","0","louis vuitton favorite","LV Favorite"],["16847","0","louis vuitton gaia","LV Gaia"],["16901","0","louis vuitton girolata","LV Girolata"],["16836","0","louis vuitton greenwich","LV Greenwich"],["16867","0","louis vuitton kensington","LV Kensington"],["16841","0","louis vuitton kimono","LV Kimono"],["16757","0","louis vuitton lockit","LV 情锁系列"],["16804","0","louis vuitton lockme","LV Lockme"],["16898","0","louis vuitton louise","LV Louise"],["16783","0","louis vuitton mabillon","LV Mabillon"],["16821","0","louis vuitton majestueux tote","LV Majestueux Tote"],["16769","0","louis vuitton marais","LV 保龄球包"],["17460","0","louis vuitton marceau","LV Marceau"],["16899","0","louis vuitton mazarine","LV Mazarine"],["16845","0","louis vuitton melie","LV Melie"],["16802","0","louis vuitton montaigne","LV 蒙田包"],["16736","0","louis vuitton neverfull","LV 购物袋/装不满包"],["16756","0","louis vuitton noe","LV 水桶包"],["16900","0","louis vuitton normandy","LV Normandy"],["16773","0","louis vuitton odeon","LV Odeon"],["16764","0","louis vuitton olympe","LV Olympe"],["17461","0","louis vuitton open","LV Open"],["16789","0","louis vuitton pallas","LV Pallas"],["16865","0","louis vuitton palm springs","LV Palm Springs"],["16735","0","louis vuitton papillon","LV  老花圆筒包"],["16868","0","louis vuitton pasadena","LV Pasadena"],["16861","0","louis vuitton petit noe","LV 水桶包小号"],["16850","0","louis vuitton petite malle","LV 小箱包"],["16896","0","louis vuitton phenix","LV Phenix"],["16827","0","louis vuitton pochette accessoires","LV Pochette Accessoires"],["17850","0","louis vuitton pochette mask","LV Pochette Mask"],["16860","0","louis vuitton pochette metis","LV 邮差包"],["16885","0","louis vuitton pochette saint germain","LV Pochette Saint Germain"],["16793","0","louis vuitton pont neuf","LV Pont Neuf"],["16852","0","louis vuitton retiro","LV Retiro"],["16829","0","louis vuitton riviera","LV Riviera"],["16834","0","louis vuitton rivoli","LV Rivoli"],["16842","0","louis vuitton rossmore","LV Rossmore"],["16886","0","louis vuitton sac lucie","Lv Sac Lucie"],["16840","0","louis vuitton saint germain","LV Saint Germain"],["16846","0","louis vuitton sc bag","LV SC"],["16884","0","louis vuitton segur","LV Segur"],["17459","0","louis vuitton sevres","LV Sevres"],["16856","0","louis vuitton siena","LV Siena"],["17857","0","louis vuitton siracusa","LV Siracusa"],["16807","0","louis vuitton soufflot","LV  Soufflot"],["16743","0","louis vuitton speedy","LV 枕头包"],["17458","0","louis vuitton sperone","LV Sperone"],["16786","0","louis vuitton sully","LV Sully"],["16781","0","louis vuitton totally","LV Totally"],["16775","0","louis vuitton tote","LV Tote"],["16904","0","louis vuitton tournon","LV Tournon"],["16795","0","louis vuitton trocadero","LV Trocadero"],["16848","0","louis vuitton turenne","LV Turenne"],["16855","0","louis vuitton twice","LV  Twice"],["16858","0","louis vuitton twist","LV 链条包"],["16871","0","louis vuitton venus","LV Venus"],["17856","0","louis vuitton vivienne lv","LV Vivienne LV"],["16905","0","louis vuitton volta","LV Volta"],["16733","0","omega constellation","欧米茄星座系列"],["16779","0","omega de ville","欧米茄碟飞系列"],["16888","0","omega ladymatic","omega ladymatic"],["16893","0","omega museum collection","omega museum collection"],["16894","0","omega olympic collection","omega olympic collection"],["16766","0","omega seamaster","欧米茄海马系列"],["16753","0","omega speedmaster","欧米茄超霸系列"],["16761","0","panerai luminor","沛纳海 Panerai"],["16879","0","panerai mare nostrum","沛纳海 Mare Nostrum"],["16880","0","panerai marina militare","沛纳海 Marina Militare"],["16787","0","panerai radiomir","沛纳海 Radiomir"],["17854","0","prada bibliotheque","普拉达 Bibliotheque"],["16866","0","prada cuir","普拉达 Cuir"],["16824","0","prada double","普拉达 Double"],["16872","0","prada esplanade","普拉达 Esplanade"],["17847","0","prada executive","普拉达 Executive"],["16815","0","prada galleria","普拉达 Galleria"],["17846","0","prada gardener's","普拉达 Gardener's"],["16831","0","prada gaufre","普拉达 Gaufre"],["16830","0","prada inside","普拉达 Inside"],["16819","0","prada lux","普拉达 Lux"],["16805","0","prada soft","普拉达 Soft"],["16839","0","prada twin pocket","普拉达 Twin Pocket"],["17853","0","prada vitello diano","普拉达 Vitello Diano"],["16800","0","rolex air king","劳力士 空中霸王系列"],["16877","0","rolex cellini","劳力士 切利尼系列"],["16874","0","rolex cosmograph","劳力士 宇宙计型迪通拿系列"],["16728","0","rolex date","劳力士 星期日历型系列"],["16873","0","rolex datejust","劳力士 日志型系列"],["16891","0","rolex day date","rolex day date"],["16799","0","rolex daytona","劳力士 迪通拿系列"],["16796","0","rolex explorer","劳力士 探险家型系列"],["16889","0","rolex gmt master","rolex gmt master"],["16767","0","rolex milgauss","劳力士 Milgauss"],["16754","0","rolex oyster perpetual","劳力士 蚝式恒动系列"],["16895","0","rolex pearlmaster","rolex pearlmaster"],["16890","0","rolex president","rolex president"],["16876","0","rolex sea dweller","劳力士 海使系列"],["16892","0","rolex sky dweller","rolex sky dweller"],["16797","0","rolex submariner","rolex submariner"],["16875","0","rolex yachtmaster","劳力士 游艇名仕系列"]]

// {//is object

//     "balenciaga" : [
//         [16780,"city"],
//         [16785,"day"],
//         [16784,"first"],
//         [16777,"le dix soft"],
//         [16758,"part time"],
//         [16803,"town"],
//         [17849,"traveler"],
//         [16823,"weekender"],
//         [16738,"work"],
//     ],
//     "celine" : [
//         [16806,"belt"],
//         [16745,"cabas"],
//         [16849,"classic box"],
//         [16763,"luggage"],
//         [16801,"phantom"],
//         [16791,"ring"],
//         [16826,"tie"],
//         [16762,"trapeze"],
//         [16808,"trio"],
//     ],
//     "赛琳" : [
//         [16806,"belt"],
//         [16745,"cabas"],
//         [16849,"classic box"],
//         [16763,"luggage"],
//         [16801,"phantom"],
//         [16791,"ring"],
//         [16826,"tie"],
//         [16762,"trapeze"],
//         [16808,"trio"],
//     ],
//     "chanel" :[
//         [16729,"boy quilted flap"],
//         [16794,"cerf tote"],
//         [16730,"classic flap"],
//         [16739,"gst"],
//         [16835,"medallion tote"],
//         [16813,"pst"],
//         [17851,"ptt"],
//         [16724,"reissue"],
//         [16881,"timeless clutch"],
//     ],
//     "香奈儿" : [
//         [16729,"boy quilted flap"],
//         [16794,"cerf tote"],
//         [16730,"classic flap"],
//         [16739,"gst"],
//         [16835,"medallion tote"],
//         [16813,"pst"],
//         [17851,"ptt"],
//         [16724,"reissue"],
//         [16881,"timeless clutch"],
//     ],
//     "chloe" : [
//         [16843,"drew"],
//         [16854,"elsie"],
//         [16853,"faye"],
//         [16869,"hudson"],
//         [16878,"kurtis"],
//         [16908,"lexa"],
//         [16809,"marcie"],
//         [16907,"milo"],
//         [18215,"mily"],
//         [16737,"paraty"],
//     ],
//     "蔻依" : [
//         [16843,"drew"],
//         [16854,"elsie"],
//         [16853,"faye"],
//         [16869,"hudson"],
//         [16878,"kurtis"],
//         [16908,"lexa"],
//         [16809,"marcie"],
//         [16907,"milo"],
//         [18215,"mily"],
//         [16737,"paraty"],
//     ],
//     "fendi" : [
//         [16771,"2 jours"],
//         //[18141,"2 jours"],
//         [17848,"3 jours"],
//         [16811,"baguette"],
//         [16782,"by the way"],
//         [16870,"dotcom"],
//         [16812,"peekaboo"],
//     ],
//     "芬迪" : [
//         [16771,"2 jours"],
//         //[18141,"2 jours"],
//         [17848,"3 jours"],
//         [16811,"baguette"],
//         [16782,"by the way"],
//         [16870,"dotcom"],
//         [16812,"peekaboo"],
//     ],
//     "hermes" : [
//         [16820,"atlas"],
//         [16742,"azap"],
//         [16741,"bearn"],
//         [16759,"berline"],
//         [16725,"birkin"],
//         [16760,"bolide"],
//         [16768,"cabag"],
//         [16746,"constance"],
//         [16822,"convoyeur"],
//         [16740,"dogon"],
//         [16765,"double sens"],
//         [16814,"egee"],
//         [16816,"envelope"],
//         [16734,"evelyne"],
//         [16770,"faco"],
//         [16744,"garden party"],
//         [16882,"garden shoulder"],
//         [16832,"hac"],
//         [16825,"halzan"],
//         [16864,"harnais"],
//         [16747,"herbag"],
//         [16883,"hermail tutti-frutti"],
//         [16817,"jige"],
//         [16727,"jypsiere"],
//         [16732,"kelly"],
//         [16731,"lindy"],
//         [17855,"massai"],
//         [16818,"medor"],
//         [18216,"oxer"],
//         [16755,"picotin"],
//         [16788,"plume"],
//         [16862,"remix"],
//         [16859,"roulis"],
//         [16748,"sac a depeche"],
//         [16778,"toolbox"],
//         [16751,"victoria"],
//         [16906,"virevolte"],
//     ],
//     "爱马仕" : [
//         [16820,"atlas"],
//         [16742,"azap"],
//         [16741,"bearn"],
//         [16759,"berline"],
//         [16725,"birkin"],
//         [16760,"bolide"],
//         [16768,"cabag"],
//         [16746,"constance"],
//         [16822,"convoyeur"],
//         [16740,"dogon"],
//         [16765,"double sens"],
//         [16814,"egee"],
//         [16816,"envelope"],
//         [16734,"evelyne"],
//         [16770,"faco"],
//         [16744,"garden party"],
//         [16882,"garden shoulder"],
//         [16832,"hac"],
//         [16825,"halzan"],
//         [16864,"harnais"],
//         [16747,"herbag"],
//         [16883,"hermail tutti-frutti"],
//         [16817,"jige"],
//         [16727,"jypsiere"],
//         [16732,"kelly"],
//         [16731,"lindy"],
//         [17855,"massai"],
//         [16818,"medor"],
//         [18216,"oxer"],
//         [16755,"picotin"],
//         [16788,"plume"],
//         [16862,"remix"],
//         [16859,"roulis"],
//         [16748,"sac a depeche"],
//         [16778,"toolbox"],
//         [16751,"victoria"],
//         [16906,"virevolte"],
//     ],
//     "louis vuitton" : [
//         [16752,"alma"],
//         [16837,"ana"],
//         [16863,"artsy"],
//         [16750,"babylone"],
//         [16838,"bagatelle"],
//         [16903,"berri"],
//         [16897,"bloomsbury"],
//         [16772,"brea"],
//         [16902,"brompton"],
//         [16857,"caissa"],
//         [16810,"calvi"],
//         [16776,"capucines"],
//         [16792,"chain louise"],
//         [16833,"city steamer "],
//         [16828,"cluny"],
//         [16726,"croisette"],
//         [17852,"deesse"],
//         [16790,"delightful"],
//         [16774,"doc"],
//         [16798,"dora"],
//         [16887,"duomo"],
//         [16851,"estrela"],
//         [16749,"eva"],
//         [17736,"explorer bag"],
//         [16844,"favorite"],
//         [16847,"gaia"],
//         [16901,"girolata"],
//         [16836,"greenwich"],
//         [16867,"kensington"],
//         [16841,"kimono"],
//         [16757,"lockit"],
//         [16804,"lockme"],
//         [16898,"louise"],
//         [16783,"mabillon"],
//         [16821,"majestueux tote"],
//         [16769,"marais"],
//         [17460,"marceau"],
//         [16899,"mazarine"],
//         [16845,"melie"],
//         [16802,"montaigne"],
//         [16736,"neverfull"],
//         [16756,"noe"],
//         [16900,"normandy"],
//         [16773,"odeon"],
//         [16764,"olympe"],
//         [17461,"open"],
//         [16789,"pallas"],
//         [16865,"palm springs"],
//         [16735,"papillon"],
//         [16868,"pasadena"],
//         [16861,"petit noe"],
//         [16850,"petite malle"],
//         [16896,"phenix"],
//         [16827,"pochette accessoires"],
//         [17850,"pochette mask"],
//         [16860,"pochette metis"],
//         [16885,"pochette saint germain"],
//         [16793,"pont neuf"],
//         [16852,"retiro"],
//         [16829,"riviera"],
//         [16834,"rivoli"],
//         [16842,"rossmore"],
//         [16886,"sac lucie"],
//         [16840,"saint germain"],
//         [16846,"sc bag"],
//         [16884,"segur"],
//         [17459,"sevres"],
//         [16856,"siena"],
//         [17857,"siracusa"],
//         [16807,"soufflot"],
//         [16743,"speedy"],
//         [17458,"sperone"],
//         [16786,"sully"],
//         [16781,"totally"],
//         [16775,"tote"],
//         [16904,"tournon"],
//         [16795,"trocadero"],
//         [16848,"turenne"],
//         [16855,"twice"],
//         [16858,"twist"],
//         [16871,"venus"],
//         [17856,"vivienne lv"],
//         [16905,"volta"],
//     ],
//     "路易威登": [
//         [16752,"alma"],
//         [16837,"ana"],
//         [16863,"artsy"],
//         [16750,"babylone"],
//         [16838,"bagatelle"],
//         [16903,"berri"],
//         [16897,"bloomsbury"],
//         [16772,"brea"],
//         [16902,"brompton"],
//         [16857,"caissa"],
//         [16810,"calvi"],
//         [16776,"capucines"],
//         [16792,"chain louise"],
//         [16833,"city steamer "],
//         [16828,"cluny"],
//         [16726,"croisette"],
//         [17852,"deesse"],
//         [16790,"delightful"],
//         [16774,"doc"],
//         [16798,"dora"],
//         [16887,"duomo"],
//         [16851,"estrela"],
//         [16749,"eva"],
//         [17736,"explorer bag"],
//         [16844,"favorite"],
//         [16847,"gaia"],
//         [16901,"girolata"],
//         [16836,"greenwich"],
//         [16867,"kensington"],
//         [16841,"kimono"],
//         [16757,"lockit"],
//         [16804,"lockme"],
//         [16898,"louise"],
//         [16783,"mabillon"],
//         [16821,"majestueux tote"],
//         [16769,"marais"],
//         [17460,"marceau"],
//         [16899,"mazarine"],
//         [16845,"melie"],
//         [16802,"montaigne"],
//         [16736,"neverfull"],
//         [16756,"noe"],
//         [16900,"normandy"],
//         [16773,"odeon"],
//         [16764,"olympe"],
//         [17461,"open"],
//         [16789,"pallas"],
//         [16865,"palm springs"],
//         [16735,"papillon"],
//         [16868,"pasadena"],
//         [16861,"petit noe"],
//         [16850,"petite malle"],
//         [16896,"phenix"],
//         [16827,"pochette accessoires"],
//         [17850,"pochette mask"],
//         [16860,"pochette metis"],
//         [16885,"pochette saint germain"],
//         [16793,"pont neuf"],
//         [16852,"retiro"],
//         [16829,"riviera"],
//         [16834,"rivoli"],
//         [16842,"rossmore"],
//         [16886,"sac lucie"],
//         [16840,"saint germain"],
//         [16846,"sc bag"],
//         [16884,"segur"],
//         [17459,"sevres"],
//         [16856,"siena"],
//         [17857,"siracusa"],
//         [16807,"soufflot"],
//         [16743,"speedy"],
//         [17458,"sperone"],
//         [16786,"sully"],
//         [16781,"totally"],
//         [16775,"tote"],
//         [16904,"tournon"],
//         [16795,"trocadero"],
//         [16848,"turenne"],
//         [16855,"twice"],
//         [16858,"twist"],
//         [16871,"venus"],
//         [17856,"vivienne lv"],
//         [16905,"volta"],
//     ],

//     "omega" : [
//         [16733,"constellation"],
//         [16779,"de ville"],
//         [16888,"ladymatic"],
//         [16893,"museum collection"],
//         [16894,"olympic collection"],
//         [16766,"seamaster"],
//         [16753,"speedmaster"],
//     ],
//     "欧米茄" : [
//         [16733,"constellation"],
//         [16779,"de ville"],
//         [16888,"ladymatic"],
//         [16893,"museum collection"],
//         [16894,"olympic collection"],
//         [16766,"seamaster"],
//         [16753,"speedmaster"],
//     ],
//     "panerai" : [
//         [16761,"luminor"],
//         [16879,"mare nostrum"],
//         [16880,"marina militare"],
//         [16787,"radiomir"],
//     ],
//     "沛纳海" : [
//         [16761,"luminor"],
//         [16879,"mare nostrum"],
//         [16880,"marina militare"],
//         [16787,"radiomir"],
//     ],
//     "prada" : [
//         [17854,"bibliotheque"],
//         [16866,"cuir"],
//         [16824,"double"],
//         [16872,"esplanade"],
//         [17847,"executive"],
//         [16815,"galleria"],
//         [17846,"gardener's"],
//         [16831,"gaufre"],
//         [16830,"inside"],
//         [16819,"lux"],
//         [16805,"soft"],
//         [16839,"twin pocket"],
//         [17853,"vitello diano"],
//     ],
//     "普拉达" : [
//         [17854,"bibliotheque"],
//         [16866,"cuir"],
//         [16824,"double"],
//         [16872,"esplanade"],
//         [17847,"executive"],
//         [16815,"galleria"],
//         [17846,"gardener's"],
//         [16831,"gaufre"],
//         [16830,"inside"],
//         [16819,"lux"],
//         [16805,"soft"],
//         [16839,"twin pocket"],
//         [17853,"vitello diano"],
//     ],
//     "rolex" : [
//         [16800,"air king"],
//         [16877,"cellini"],
//         [16874,"cosmograph"],
//         [16728,"date"],
//         [16873,"datejust"],
//         [16891,"day date"],
//         [16799,"daytona"],
//         [16796,"explorer"],
//         [16889,"gmt master"],
//         [16767,"milgauss"],
//         [16754,"oyster perpetual"],
//         [16895,"pearlmaster"],
//         [16890,"president"],
//         [16876,"sea dweller"],
//         [16892,"sky dweller"],
//         [16797,"submariner"],
//         [16875,"yachtmaster"],
//     ],
//     "劳力士" : [
//         [16800,"air king"],
//         [16877,"cellini"],
//         [16874,"cosmograph"],
//         [16728,"date"],
//         [16873,"datejust"],
//         [16891,"day date"],
//         [16799,"daytona"],
//         [16796,"explorer"],
//         [16889,"gmt master"],
//         [16767,"milgauss"],
//         [16754,"oyster perpetual"],
//         [16895,"pearlmaster"],
//         [16890,"president"],
//         [16876,"sea dweller"],
//         [16892,"sky dweller"],
//         [16797,"submariner"],
//         [16875,"yachtmaster"],
//     ],
// };

var stylesid = [["1554","0","Shoulder Bags","肩背包 "],["1556","0","Wallets and Small Accessories","钱包及配件 "],["1557","0","Clutches","手包 "],["1558","0","Totes","手提包 "],["1559","0","Backpacks","背包 "],["1561","0","Briefcases","公文包 "],["1567","0","Others","其他 "],["1568","0","Wrist Watches","腕表 "],["1873","0","Luggage and Travelling bags","旅行包及行李箱 "],["5603","0","Wallets and small items","钱包及饰物"]]
// [
// [1554,0,"Shoulder Bags","肩背包"], 
// [1556,0,"Wallets and Small Accessories","钱包及配件"], 
// [1557,0,"Clutches","手包"], 
// [1558,0,"Totes","手提包"], 
// [1559,0,"Backpacks","背包"], 
// [1561,0,"Briefcases","公文包"], 
// [1567,0,"Others","其他"], 
// [1568,0,"Wrist Watches","腕表"], 
// [1873,0,"Luggage and Travelling bags","旅行包及行李箱"], 
// [5603,0,"Wallets and small items","钱包及饰物"]
// ]


var inventory = //** must be small letter
{"backpacks":{"balenciaga":{"balenciaga city":"All","balenciaga traveler":"All","other":"藍色,灰色，蓝色，黑色,蓝色，白色,黑色"},"bottega veneta":{"other":"宝石蓝"},"celine":{"other":"黑色,棕褐色"},"chanel":{"chanel reissue":"All","other":"珍珠白色,紅色,黑色,DARK BLUE,BLUE"},"chloe":{"chloe faye":"All","other":""},"christian dior":{"other":"All"},"coach":{"other":"深灰,蓝色,黑灰红边,黑色,粉笔白,黄色,深蓝,咖色,炭灰色,藏蓝色,蔚蓝色,红色,灰色,玫红色,黑色配蓝色,棕色,橘色,蓝绿色,青铜色,绿松石,酒红色,水蓝,彩色"},"designer brands":{"other":"All"},"fendi":{"fendi 2 jours":"All","fendi by the way":"All","fendi peekaboo":"黑色,红色","other":"黑色,綠色,杏色,紅色,黑色,混色,花色,玫红色,蓝色+黑色,拼色,浅蓝色,黑色,灰色,黑色,电光蓝,灰色,黑色、灰色、黄色,多色拼色,蓝色,粉色,Black"},"givenchy":{"other":"黑色拼色,黑色,多色,棕色，灰白,Black"},"gucci":{"other":"啡色,深藍色,藍色,紅色,米色,乌木色,印花色,灰色,粉米色,粉红色,黄色,黑色,红色,棕色,深蓝色,蓝色,米色,棕色,天竺葵印花,蓝色印花,紅綠色,拼色,深棕色,Black"},"hermes":{"hermes herbag":"Ecru色,米白色","hermes kelly":"Marron色, 深啡色","other":"Sienne色,啡色,Blue Ocean色,深藍色,Noir色,黑色,YELLOW"},"louis vuitton":{"louis vuitton mabillon":"黑色","louis vuitton palm springs":"咖色,Brown","other":"啡色,棕色,BROWN,COBALT"},"michael kors":{"other":"桃紅色,红色,Black,樱桃红色,樱桃红,棕色,深蓝色,黑色,粉色,紅色,浅咖啡,棕,棕色印花,粉玫瑰色,浅蓝色,珊瑚色,藏蓝色,绿色,粉玫瑰红色,砖红色,蓝黑,莫斯色,灰白色,黑色,卡其色,浅蓝色,蓝色,白色,玫红色、宝蓝色,棕色、灰蓝色,水泥灰、沙色,电光蓝,水泥灰,黄色,红色,粉色,煤渣灰,梅红色,苔藓绿,香草色,红色、黑色等,多色,黑色等,炭灰色,森林绿色,紫红,橙色,暗牛仔色"},"miu miu":{"other":"黑色,酒红色,拼色,蓝色,黑色,群青色"},"prada":{"prada double":"All","prada soft":"All","other":"Black,黑色,迷彩蓝色,黑色等,蓝色,藍色,深蓝色,其他,黑色,蓝色,黑色机器人,玫粉色,红色,军绿色,黑色,黄色,藏蓝色,多色,桃红色"},"salvatore ferragamo":{"other":"玫红色,浅粉色,黑色+咖啡色"},"tory burch":{"other":"Black,黑色,法国灰色"},"valentino":{"other":"綠色,Multicolor,蓝色,绿色,多色,黑色,黄色,蓝黑色,黑,軍綠色,迷彩,Yellow"},"yves saint laurent":{"other":"其他,黑色"}},"briefcases":{"bottega veneta":{"other":"藍色,深綠色,深啡色,藏蓝色,蓝色,其他,黑色,棕色,-"},"cartier":{"other":"All"},"chanel":{"other":"黑色"},"christian dior":{"other":"All"},"coach":{"other":"红棕色"},"fendi":{"other":"蓝色,黑色"},"givenchy":{"other":"All"},"gucci":{"other":"灰蓝色,卡其色,深蓝色,雅灰,棕色,黑色,乌木色,黑色,米色,蓝色,蓝色,啡色"},"hermes":{"hermes sac a depeche":"Noir色,黑色","other":""},"louis vuitton":{"louis vuitton doc":"啡色,蓝色","louis vuitton rivoli":"All","other":"黑色,啡色,黑色,啡色,灰棋格"},"michael kors":{"other":"All"},"prada":{"prada cuir":"All","other":"黑色,藏蓝色,红色,灰色,黑色 蓝色"},"salvatore ferragamo":{"other":"黑色,灰绿色"},"valentino":{"other":"All"},"yves saint laurent":{"other":"All"}},"clutches":{"balenciaga":{"balenciaga city":"All","other":"粉紅色,淺藍色,紅色,藍色,綠色,黑色,軍綠色,藏蓝色,紫色,墨绿,深棕色,矢车菊蓝,紫红色,绿色,貂米色,深蓝色,橙红色,蓝色,云灰色,松林绿,波尔多红,深渊蓝,红色"},"bottega veneta":{"other":"深藍色,啡色,黑咖色,黑色,蓝绿拼色,其他,深棕色,深蓝色,红色,蓝色,裸粉色,藏青色,深咖色,深灰色,藏蓝色,棕色,兰绿色"},"bulgari":{"other":"All"},"cartier":{"other":"灰色"},"celine":{"celine classic box":"All","celine luggage":"All","other":"橙色, 紅色,淺啡色,金色,黃綠色,黑色,海军蓝,芭蕾粉和烟黑色双色,午夜黑,驼色,淡灰色和深红色,黑色拼银色"},"chanel":{"chanel boy quilted flap":"紅色,藍色","chanel classic flap":"All","chanel reissue":"All","chanel timeless clutch":"All","other":"珍珠灰色,紅色,紫色,黃色,淺紅色,黑色,Black,Pink"},"chloe":{"chloe faye":"All","other":"灰色"},"christian dior":{"other":"白色,黑色,-"},"coach":{"other":"灰色,黑色,啡色,白色,黑色,乳白色,森林绿"},"designer brands":{"other":"All"},"fendi":{"fendi baguette":"All","fendi peekaboo":"All","other":"黑色,黃色,多色"},"givenchy":{"other":"紫色,黑色,浅粉色,棕色,棕色，米色,粉红色,霓虹粉色,榛子棕,玫红色,多色,蓝色,粉色,酒红色,拼色"},"gucci":{"other":"黑色,紅色,蓝色,棕色,深蓝色,红色,绿色,米白色,卡其色,浅卡其色,金棕色,蓝色印花,其他,海蓝色,米黄色,米色,深棕色,卡其色配黑色,深粉色,乌木色"},"hermes":{"hermes egee":"Havane色,紫啡色","hermes envelope":"All","hermes jige":"Noir色,黑色","hermes kelly":"All","hermes medor":"All","hermes virevolte":"All","other":"Noir色,Rose Lipstick色,粉紅色,Rouge Pivoine色, 紅色,Rouge H色,酒紅色,Rouge Vermillon色, 紅色,Rose shocking色,粉紅色,Chocolat色,深啡色,黑色"},"louis vuitton":{"louis vuitton ana":"All","louis vuitton chain louise":"All","louis vuitton doc":"藍色","louis vuitton eva":"All","louis vuitton lockit":"All","louis vuitton montaigne":"All","louis vuitton pochette accessoires":"All","louis vuitton pochette metis":"All","louis vuitton rossmore":"All","other":"黑色,啡色,黃色"},"michael kors":{"other":"金色"},"miu miu":{"other":"酒紅色,米色,淺銅色,黑色,啡色,灰色,紫色,拼色,蓝绿色,桃粉色,Rosa (Designer Colour),Pirite (Designer Colour),粉色,蓝色,玫红色,粉色+裸粉色+米白色,浅蓝色+蓝色"},"prada":{"prada gaufre":"All","prada lux":"All","other":"深灰色,桃紅色,紫色,黑色,藏蓝色,蓝色、黑色等,樱花粉色,红色,其他,他,蓝色,棕色,藍色"},"salvatore ferragamo":{"other":"黑色,黑色等,其他,深咖色 黑色,深蓝色 黑色 灰色,枣红色,宝蓝色,深蓝色,灰绿色,莓红色,芭蕾粉,黄色"},"tiffany & co":{"other":"All"},"tory burch":{"other":"粉色,黑色"},"valentino":{"other":"卡其色,米白色,粉紅色,暗紅色,藍色,迷彩,迷彩拼色,綠色,混色,图案,深蓝色,拼色,暗绿色,黑色,红色,浅棕色,绿色"},"yves saint laurent":{"other":"棕色,深酒红 海蓝色 黑色,黑色"}},"luggage and travelling bags":{"balenciaga":{"balenciaga city":"All","balenciaga traveler":"All"},"bottega veneta":{"other":"All"},"celine":{"celine luggage":"All"},"chanel":{"other":"All"},"christian dior":{"other":"All"},"coach":{"other":"All"},"fendi":{"other":"All"},"gucci":{"other":"啡色,黑色"},"hermes":{"hermes kelly":"All","hermes victoria":"All","other":""},"louis vuitton":{"louis vuitton eva":"All","louis vuitton greenwich":"All","louis vuitton lockit":"All","louis vuitton speedy":"All","other":"啡色,靛蓝色"},"michael kors":{"other":"All"},"prada":{"other":"All"},"salvatore ferragamo":{"other":"All"},"tory burch":{"other":"All"},"valentino":{"other":"All"},"yves saint laurent":{"other":"All"}},"others":{"balenciaga":{"balenciaga city":"All","balenciaga le dix soft":"All","balenciaga work":"All","other":"白色,黑色,Blue,Pink,Purple,柠檬黄,深灰色,藏青色,天蓝色,荧光黄,紫红色,深蓝色,蓝色"},"bottega veneta":{"other":"啡色,白色,黑色,黃色,Blue,褐色,米白色,Black"},"bulgari":{"other":"純銀, 黃金,銀色,金色,白金,白金, 黃金, 玫瑰,黃金,玫瑰金,黃全,銀色,玫瑰金,玫瑰金,藍色,玫瑰金,白色"},"cartier":{"other":"金色,金色, 橙色,白金,白金,碧璽,月亮石,海藍寶石,堇青石,石榴石色,鉑金,鑽石,白金,鑽石,金色,銀色,鉑金,黃金,黃金、 白金、 玫瑰金,玫瑰金,18K白金,鑽石,純銀,玫瑰金,白金色,銀色,銅色,白金,玫瑰金,黃金,黃金,白金,玫瑰金,黃金,黑色,黄金,玫瑰金,銀色,白色,金色,銀色,玫瑰金,白金, 黃金, 玫瑰金,白金,黃金,玫瑰金,18K白金Love Ring戒指,金色, 銀色, 玫瑰金色"},"celine":{"celine belt":"藍色","celine cabas":"All","celine luggage":"黑色","celine phantom":"All","other":"啡色,紅色,白色"},"chanel":{"chanel boy quilted flap":"紅色,Beige","chanel gst":"黑色","chanel reissue":"All","other":"紫色,白色, 金色,湖藍色, 銀色,銀色,啡色,紫色,白金,金色, 粉紅色,金色,白色,金色,白色,紅色,粉橙色,橙色,金色,白色,金色,金色,黑色,金色,紅色,紫色,黑色,淺金色,白色,粉紅色,啡色,金色, 白色,銀色,黑色,金屬水鑽杜拜限量版月亮CC項鏈金色,藍色,白色,珍珠,銀,Beige,金色,黑色,白色,Begin,銀色,白色,黑色,銀色,金色,綠色,白色,黑色,黑色,紅色,黑白色,藍色,白色, 銀色,桃红色,金色+藍色+綠色,Metallic,GOLD,PINK,GOLD BLACK,SILVER BLACK,BRONZE GOLD,WHITE,RED,SILVER,BLACK,BLUE,SILVER,BLACK,WHITE,GOLD"},"chloe":{"chloe drew":"All","chloe hudson":"All","chloe marcie":"All","other":"啡色,灰色,銀色"},"christian dior":{"other":"金屬,金色, 黑色,灰色,銀色,銀色,米白色,啡色,黑色,Orange"},"coach":{"other":"銀色,黑色,Navy (Designer Colour),True Red (Designer Colour),橄榄绿,藏蓝色,紫色,红色,蓝绿色"},"designer brands":{"other":"All"},"fendi":{"fendi by the way":"All","fendi dotcom":"All","fendi peekaboo":"All","other":"金屬,粉紅色,黑色,紅色,紫色,藍色,黑色,裸色,黑色,灰色,灰色,黃色,橙色,藍色,藍色,多色,灰蓝色,黑色,肤色+多色,tiffany蓝,红色"},"givenchy":{"other":"啡色,多色,Multi,钢青色,黑色"},"gucci":{"other":"銀色,黑色,黃色,米白色,啡色,純銀,卡其色,蓝色,彩色,拼色,深紫色,粉色,深玫红色,印花,Blue"},"hermes":{"hermes azap":"Jaipur","hermes berline":"黑色","hermes birkin":"紅色,白色,藍色,藍色,blue jeans","hermes bolide":"橙色,5E VERMILLION GP","hermes constance":"White,T5 ROSE JAIPUR","hermes evelyne":"All","hermes hermail tutti-frutti":"ROUGE GRENADE","hermes jige":"8L BETON,7B TURQUOISE BLEU PETROLE,89 NOIR,C9 SOUFRE","hermes kelly":"Tosca, 紫色,橙色,Noir色,黑色,白色,藍色,Terre Battue色,深橙色,粉色,玫瑰金,Cassis色,紫色,Bleu Saphir色,寶藍色,Orange,78 BLEU MARINE,Q5 ROUGE CASAQUE","hermes lindy":"BLUE JEANS","hermes medor":"8B GRIOLET,96 VIOLET","hermes picotin":"Crevette,藍色","hermes sac a depeche":"All","other":"橙色,藍色,Rose Jaipur,西瓜紅,Blue Sapphire色,Colvert,藍色,彩色,桃紅色,Marine x Black x White,Anis Green,淺綠色,藍色,黑色,紅色,白色,黑色,Feu,橙色,Gold色, 啡色,Soufre,黃色,Blue Lin色,玫瑰金,純銀,Bleu royale色,藍黑色,金色,啡色,藍色,Z6,Grey,黃色,金色,Raisin色,紫色,黑色,啡色,Noir色,黑色,Rouge pivoine色,銀色,Rouge Indien色,紅色,Sienne色,紅色,啡色,黑色,白色,米色,金色,白色,藍色,綠色,玫瑰金色,銀色,tosca,rase jaipur,桃紅色,綠色,多色,灰褐色,灰褐色,藍紫色,綠色,藍色,藍色,玫瑰金色,米色,紫色,白色,粉紅色,Sanguine色,橙色,橙色,藍色,銀色,橙色,紅色,Feu色,橙色,粉色,藍色,紫色,啡色,啡色,橙色,啡色,綠色,橙色,金色,金色,Gold色,啡色,紅色,藍色,黑色+黃色,Beige色,Yellow,White,Blue,Black,10 BLK,5Z,37 GOLD,9R , V6,9R,A5,S5,SILVER,ROSE GOLD,45 , 55,MULTICOLOR,MULTI COLOUR,93 ORANGE,2R ROUGE PIVOINE,5A ORANGE PALE,5R,6W MENTHE,7M BLEU AZTEQUE,89,47 NOIR,CHOCOLATE,89 , 7P,89,7T,8W ROSE AZALEE,96 VIOLET,C9,K5 TOSCA,BLACK,MULTIC COLOUR,89 NOIR,9R LIME,8V 8W 7M,5Z T5 9J,BLACK,WHITE,PURPLE,ORANGE,PINK,89 NOIR GP"},"louis vuitton":{"louis vuitton alma":"透明,紅色,黑色,米黃色,紅色","louis vuitton artsy":"All","louis vuitton brea":"All","louis vuitton capucines":"All","louis vuitton city steamer ":"All","louis vuitton cluny":"All","louis vuitton croisette":"All","louis vuitton delightful":"All","louis vuitton doc":"All","louis vuitton dora":"All","louis vuitton duomo":"All","louis vuitton eva":"紅色","louis vuitton greenwich":"All","louis vuitton lockit":"All","louis vuitton lockme":"All","louis vuitton marais":"All","louis vuitton montaigne":"All","louis vuitton neverfull":"All","louis vuitton noe":"All","louis vuitton olympe":"All","louis vuitton papillon":"All","louis vuitton pont neuf":"All","louis vuitton segur":"All","louis vuitton siracusa":"All","louis vuitton soufflot":"purple","louis vuitton speedy":"啡色","louis vuitton tote":"米色","louis vuitton trocadero":"All","louis vuitton twist":"All","other":"啡色,金色,古銅色,黑色,橙啡色,深啡色,藍色,裸色,粉紅色,紅色,深紫紅色,白色,川上龍,白色,銀灰色,杏色,紅色,啡色,白色,淺綠,橙色,金色,黃色,粉紅色,米色,金色,白色,啡色,綠色,紫色,淺啡,Blue,BROWN,GREY,BRWON,BLACK , WHITE,BLACK,NAVY,BLACK MONOGRAM,BRWON MONOGRAM,BROWN MONOGRAM,ROSE BALLERINE"},"michael kors":{"other":"棕色,丁香紫,珊瑚红,藏青色,淡紫色,钢蓝色,灰蓝色,橘粉色,蓝色,奶白色,浅灰色,青瓷色,深棕色,桃粉色,天蓝色"},"miu miu":{"other":"金色,粉紅色,Beige,黑色,黑色，木瓜橘,黑色,蓝色"},"omega":{"omega de ville":"All","omega speedmaster":"All"},"prada":{"prada bibliotheque":"All","prada double":"All","prada galleria":"All","prada lux":"All","other":"淺藍色,粉紅色,綠色,白色,black+brown,purple,Beige,黑色,木槿花紅,深蓝色,牡丹粉,灰色,RED,Black"},"rolex":{"rolex date":"金色,銀色,黑色,黑色","rolex gmt master":"銀色","rolex milgauss":"銀色","rolex oyster perpetual":"All","other":"All"},"salvatore ferragamo":{"other":"黑色,New Bisque (Designer Colour),Anemone (Designer Colour),海葵紫,红色,玫粉色,玫红色,深紫色,香槟粉,碧蓝色,暗红色,藏青色,玫粉色+白色+褐色,黑色+粉色+黄色,多色,深褐色,裸色,粉色"},"tiffany & co":{"other":"鉑金色,鉑金,純銀,銀色,黃金,白金,silver,玫瑰金,金色,藍色,925純銀"},"tory burch":{"other":"甜瓜色,黑色+绿色,浅灰色"},"valentino":{"other":"姜黄色+黑色,玫红色+黑色,桔色,橘红色,橘色,蓝灰色"},"yves saint laurent":{"other":"黑色,銀色,銀色,淺啡色,金色,藏青色,宝蓝色,深玫红色"}},"shoulder bags":{"balenciaga":{"balenciaga city":"紅色,米白色,綠色,灰色,深紅色,橙色,Black","balenciaga day":"淺藍色,灰色,深綠色","balenciaga first":"All","balenciaga le dix soft":"墨綠色","balenciaga part time":"米色,黃色,啡色,黑色","balenciaga town":"All","balenciaga weekender":"黑色","balenciaga work":"All","other":"湖水藍色,黃色,橙色,啡色,桃紅色,粉色,紫紅色,pink,黑色,粉红色,紫色,灰色,粉紅色,米色,綠色,梅紅色,淺粉紅色,粉紅色,紫藍色,泥黃色,紅色,Blue,浅蓝色,蓝色,红色,Gris Chartreux (Designer Colour),橙红色,藏蓝色,紫红色,化石灰,深蓝,绿色,深蓝色,米色紫貂,白色，蓝色,果仁米色,紫罗兰色,灰褐色,深灰色,藏青色,胭脂色,多色,桃红色,绣球花粉,貂米色,胭脂红"},"bottega veneta":{"other":"銅色,杏色,藍色,白色,深紫色,粉紅色,紫色,blacku0026silver,啡色,深藍色,啡色,黑色,淺灰色,啡紅色,深紅色,綠色,黃色,啡色,金色,灰色,灰綠色,深啡色,金色,橘紅色,橙色,淺紅色,銀色,紅色,蓝色,棕色,咖啡色,淡粉色,深咖啡,红棕色,Marrone (Designer Colour),深咖啡色,咖色,绿色,紫蓝色,其他,酒红色,荧光黄,浅紫色,玫瑰金色,浅棕色,藏蓝色,银灰色,深灰色,玫紅,深银色,蓝黑色,深蓝色、灰绿色"},"bulgari":{"other":"米色,碧玺粉红色,黑色,宝石红,碧玉火焰红"},"cartier":{"other":"All"},"celine":{"celine belt":"灰色,芭蕾粉,米色","celine cabas":"紅色,黃色,棕褐色,黑色,深宝石红和海军蓝,海军蓝和米色,浅卡其色和奶白色,黑色和白色","celine luggage":"黑色,啡色,杏色,藍色,紅色,黑色,紅色,黑白拼色","celine phantom":"深蓝色,棕褐色,黑色和海军蓝,海军蓝渐变色条纹,奶白色,肉桂色,炭黑色,沙丘色","celine ring":"啡綠色","celine trapeze":"黑色, 深啡色, 米色,黑色,卡其色,橙色,綠色,深藍色,啡紅色,橙色,紅色,啡色,白色,杏色,黑色,橙紅色,黑色,啡色,深藍色,綠色,黑蓝拼色,黑白拼色,海军蓝","celine trio":"黃色,花瓣色,香草色,Black","other":"橙色,啡色,藍色,紅色,黑色, 紅色, 啡色,金色,啡色,白色,淺藍色, 啡色, 米色,啡色,黑色,桃紅色,啡色,黃色,灰色,綠色,黑色,灰色,米白色,紅色,藍色,桃紅色,酒紅色,橙色,綠色,灰色,杏色,白色,brown,藍色,棗紅色,啡色,酒紅色,橙紅色,粉紅色,藍色,焦红色,香草色,汽油蓝,中度蓝色,梅洛红,天然色,灰褐色,浅米色,中度蓝,芭蕾粉,酒红色,瓷蓝色,棕褐色,花瓣色,深绿色与矿石蓝,黑色与向日葵色,白色与洋红色,深绿色和矿石蓝,焦红色和白色,焦红色和洋红色,海军蓝和黑色,黑白双色,向日葵色和白色,浅驼色,红色,矿石蓝,奶白色,浅卡其色,肉桂色,水晶紫,胭脂粉,烟灰色,栗色,米色,金黄色,深绿色,赤陶色,柠檬绿双色,玉兰色,黑色波点,淡粉色,奶白色和海军蓝,赤陶色和海军蓝,矿石蓝和深绿色,向日葵色,罂粟红,黑色和矿物色,茶色,蓝色,多色,水仙黄,淡紫黑色"},"chanel":{"chanel boy quilted flap":"啡色,墨綠色,黑色,墨綠色,藍色,啡色,深紅色,酒紅色,深藍色,杏色,深橙色,紅色,米色,灰色,黑色,金色,紫色,藍綠色,深啡色,桃紅色,香檳金色,粉紫色,深紅色,淺橙色,深灰色,黃色,綠色,Black,Blue,Pink,PINK","chanel classic flap":"藍色,啡色,黑,白色,橙色,米白色,紅色,白色,橙紅色,黑色,白色,深藍色,灰色,粉紅色,Blue,Red,Black,RED ORANGE","chanel gst":"橙色,裸色,淺粉紅色,黑色","chanel pst":"黑色","chanel reissue":"紅色,淺灰色,灰色,Grey,黑色,銅色,灰藍色,藍色,紫色,深藍色,白色,銀色,粉紅色,古銅色,香檳色,湖水綠色","chanel timeless clutch":"All","other":"深啡色,紅色+金色,金色,紅色,黑色, 藍色,薄荷綠色,黑色,啡色,杏色,白色, 黑色,粉紅色,深藍色,黃色,藍色,Black,米色, 黑色,米色,銀色,灰色,米白色,深綠色,紫色,粉色,灰綠色,黑色,金色,淺藍色,黑色,白色,桃紅色,黑色, 米色,墨綠色,灰色,灰褐色,酒紅色,橙紅色,啡色, 黑色,白色,藍色,紫紅色,綠松石綠,電光藍色,橙色,白色,灰色,黑色,灰黑色,普魯士藍色,灰土色,白色,粉色,銅色,蝦肉色,灰啡色,卡其色,米色,黑色,水藍色,白色,黑色,啡紅色,紅色,白色,藍綠色,軍綠色,黑色,米白色,黑色, 深藍色,黑色,紫色,彩色,綠色,橙啡色,橙色,米色,裸色,淺啡色,灰藍色,深綠色,黑色,深藍色, 啡紅色,孔雀藍色,紫藍色,黑色, 灰黑色,淺灰色,黑色,米色,酒紅色,粉紅色,啡色,紫色,綠色,藍色,灰色,深藍色,啡色,土灰色,酒紅色,藍色,啡綠色,深藍色,淺藍色,紅色,啡黃色,酒紅色,啡綠色,暗灰色,深紅色,啡綠色,淺紅色,透明,白色,墨綠色,黑色,多色,白色,多色,黑色,裸色,玫紅色,黑色,灰色,金色,黑色,淺金色,裸色,銀色,黑色,黑色,紅色,淺灰,藍色,白色,透明灰色,白色,淡金色,淺金色,青金色,深橄欖綠色,深灰色,銀灰色,灰色深藍色,紅色,黑色,米黃色,Beige,棗紅色,白色,紅色,藍色,啡色,淺大象灰色,啡色,藍色,多色,透明,淺粉紅色,暗粉紅色,深紅色,灰銀色,藍色, 紅色, 白色,香檳金色,銀白色,紫色,綠色,深粉紅色,粉藍色,深藍色, 米色,紅色,金色,Red,White,Grey,Green,Pink,Brown,粉白格子,LIGHT BLUE,DARK BLUE,LIGHT PURPLE,LIGHT PINK,PINK,RED,BLACK,BLUE,BLACK ,GOLD,BLACK u0026 RED"},"chloe":{"chloe drew":"黑色,裸粉,红色,暗桃红,紫红色,紫色,黄色,蓝色,啡色,赭红,浅蓝色,灰色","chloe elsie":"All","chloe faye":"米色,橙红色,黑色,棕色,深绿色,蓝,芥末色,灰色","chloe hudson":"黑色,酒红色,灰色,深蓝色","chloe kurtis":"咖色,灰色","chloe lexa":"All","chloe marcie":"灰藍色,红色,黑色","chloe mily":"All","chloe paraty":"灰色,白色","other":"橙色,黑色,米色,紅色,藍色,深紅色,黑色,玫紅色,灰褐色,黑色,桃紅色,灰色,肉粉色"},"christian dior":{"other":"紅色,青綠色,白色,粉紅色,黑色,淺綠色,天藍色,紫色,泥黃色,灰色,紫紅色,灰色,黄色,金色,蓝色,浅粉红色,鲜红色,夜蓝色,银色"},"coach":{"other":"啡色,粉紅色,橘紅色,淺金色,黑色,深藍色,啡色,橙色,米色,黑色,啡色, 桃紅色,啡色,桃紅色,杏色,灰色,黑色,灰色,米色,白色,黑色,藍綠色,橙色,杏色,白色,桃紅色,白色,淺灰色,暗黃色,紅色,淺黃色,淺粉紅色,啡色,粉紅色,紅色,啡色,藍色+紫色,青铜色,棕色,Black,Red,Brown,紫色,酒红色,卡其色,卡其浅绿边,粉色,紫红色,橘色 浅蓝色,红色,粉红,米黄色,深棕,浅棕色,鲜红,紫红,黄 紫 白,褐色,枚红色,深棕 浅棕,蓝色,拼色,红,其它,深棕色,橘红色,玫红色,黄色,玫红 黑色 红,桔色 蓝色 黑色,绿色,裸色,海军蓝,卡其,棕色,浅棕 深棕玫红边,咖啡,咖色,黑 绿 桔 蓝,黑灰 深棕,黑,藍, 紅,草绿,香槟色,黑 棕 玫紫,棕色 蓝色,深蓝色,橘色,豹纹,浅粉 浅蓝,浅蓝,浅咖色,肉桂色,藏蓝色,印花色,浅蓝 粉 玫红 蓝色,大丽花色,淡黄,浅薄荷绿,淡紫色,深咖色,灰 白,True Red (Designer Colour),红 粉,蓝黑拼色,花色,玫红,红底花色,黑色红边,灰黑色,天蓝色,黑 深蓝 深粉,玫粉色,Dahlia (Designer Colour),马鞍棕,炭灰色,红棕,蓝黑色,玫紫 桔红,紫红 蓝色 杏色,蓝黑拼接,金属银色,紫粉色,深红色,蔚蓝,海军蓝,金丝雀,粉白,棕黑拼色,深蓝,浅棕,卡其黄色,卡其玫红色,彩虹拼色白,深紫色,绿色配深蓝色,棕色配黑色,薄荷绿,樱桃色,橄榄绿,深咖色,紫色,深棕印花,蓝灰色,银色,黑灰色,卡其棕色,其他,黑条白色拼接,灰色蛇皮,黑棕色,烫金,军绿色,孔雀蓝色,白底印花色,樱桃红,深红,卡其色,棕色,金属蓝黑,军绿,深咖啡色"},"designer brands":{"other":"All"},"fendi":{"fendi 2 jours":"酒紅色,紫紅色,啡色,Pink","fendi 2jours":"黄色","fendi baguette":"金色,古銅色,红色,玫红色,深蓝色","fendi by the way":"淺藍色,深藍色,紫色","fendi dotcom":"All","fendi peekaboo":"黃色","other":"彩色,淺啡色,紅色,桃紅色,啡色,銀色,淺藍色,藍色,白色,粉紅色,黃色,透明, 啡色,杏色,紅色,淺啡色,粉紅色,橙色,白色,啡色,紫色,白色,幻彩色,藍色,白色,粉紅色,黑色,米白色,灰色,珍珠白色,桃紅色,橙色,啡色,米白色,藍色,薰衣草紫,金色,银灰,黃色,蓝紫,薄荷绿,金色,银色,薰衣草蓝,烟草色,棕色,酒红色,黄色,红色,蓝色,深蓝色,多色,黑色，黄色,粉色,粉紫色,碳灰色,蓝紫色,灰白色,拼色,暗红"},"givenchy":{"other":"藍色,黑色,裸色, 黑色,杏色,淺啡色,紅色,粉紅色,Grey,红色,Red,粉蓝色,褐色,霓虹粉,酒红色,深紫色,橙色,波尔多红,橘色,粉红,粉红色,粉色,玫红色,多色,波尔多酒红色,蓝色,深棕"},"gucci":{"other":"銀色,深啡色,啡色,黑色,米色,酒紅色,粉紅色,白色,黑色,彩色,黃色,黑色, 啡色,黑色,橙色,藍色,紅色,米色,啡色,深粉紅色,米白色,啡色,粉紅,灰黑色,米色,淺紫色,深藍色,金色,橙色,紅色,黑色,Orange,紫色,灰色, 紅色,浅褐色,棕色,乌木色,红色,银色,蓝色,裸色,黄色,浅蓝色,黑白拼色,粉色,芙蓉红,浅粉色,米色,乌木色,米色,棕色,白色,芙蓉红,蓝色,绿色,深蓝色,桃红色,米色,浅蓝色,浅粉色,浅粉色,米色,芙蓉红,祖母绿,糖果粉,红色,蓝色,白色,蓝色,白色,粉米色,Black,卡其色,请见详图,蜜桃粉,卡其配棕色,灰拼粉色,咖啡色,紫红色,深咖啡色,枚红色,芙蓉红色,咖啡色 紫色 粉色 橙色,浅咖色,裸粉色,拼色,杏色,其他,粉红色,金属灰色,橘黄色,蓝绿色,浅黄,灰色,橘红色,浅米色,橙咖色,深棕色,天竺葵蓝色,暗蓝色,红色,紫红色,天蓝色,金属色,棕褐色,印花,枫叶棕,深紫色,紫粉色,天竺葵,暗粉紫色,深红色,红色+白色,浅棕色,米色，棕色,深咖色,玫红色,卡其,兰花,粉红,米色，蓝色，芙蓉红,黑棕色,暗红色,棕色,黑色,咖色,蓝色,红,酒红色,蓝色拼色,彩色,孔雀绿"},"hermes":{"hermes atlas":"All","hermes berline":"紅色,Crevette色,橙色,Orange Poppy色,橙色,7F BLEU PAON,9V JAUNNE D’OR,89 NOIR,8F ETAIN SS,8F ETAIN,3Z BLEU SAINT CYR,2T BLEU PARADIS,73 BLEU SAPHIR,37 GOLD , 58 PRUNE","hermes birkin":"啡色,Blue Obscurs色,深藍色,Anis Green,绿色,Bleu Saphir色,深藍色,Tabac Camel色,啡色","hermes bolide":"Feu, 橙色,Orange色,橙色,Blue Jean色, 淺藍色,藍色,Argile色,米色,Gold色,啡色","hermes cabag":"Etain色,Bleu lin色,啡色,灰藍色,啡色","hermes constance":"Chocolat色,Noir色, 黑色,Noir色,黑色,Bleu Saphir色,藍色,黑色,Noir,Bleu De Galice色,藍色,Blue,78 BLEU MARINE","hermes convoyeur":"93 ORANGE","hermes double sens":"Tosca色,Noisette色,紫色,啡色,Violet色,Bleu De Malte色,藍色,Sanguine色,Gold色,深橙色,啡色,Gris Perle色,Vermillon色,淺灰色,紅色","hermes envelope":"All","hermes evelyne":"Bleu Indigo, 深蓝色,Soufre色,黃色,Rose sakura色,粉紅色,36 ROUGE PIVOINE BRIQUE,7F BLEU PAON,ORANGE POPPY,Z6 MALACHITE,N7,T5","hermes faco":"Chocolat色,啡色,Ultraviolet色,Gigare色,Noir色,深紫色,啡色,黑色","hermes garden party":"All","hermes halzan":"All","hermes herbag":"粉紅色,Noir色, Rouge H色,藍色,Bleu De Galice,Rose confetti色, 粉紅色,Anemone色, 紫色,Orange色,橙色,Rubis色,Bleu Marine色,紫色,深藍色,Rough H色,紅色,紫色,Bleu Indigo色,深藍色,Raisin色,紫色,Orange Poppy色,罌粟橙色,Natural,櫻花粉,Etoupe色,啡色,Noir色,黑色,Noisette色,Ecru色,啡紅色,米白色","hermes jypsiere":"Chocolate色, 深啡色,Electric Blue,藍色,Graphite色,灰色,Crevette色,粉紅色,Gris Tourterelle色,灰褐色,Orange色,Moutarde色,深橙色,橙色","hermes kelly":"橙色,Fue,Brique色, 暗紅色,黑色,Noir,Gold色, Orange色,Capucine,Orange, 橙色,Chocolat色,Rouge Garance色,紅色,Orange色,Noir色,Orange色, 橙色,Noir色, 黑色,Gold色,Rouge H色, 暗紅色,Blue De Malte色, 深藍色,Bleu Saint Cyr, 湖藍色,Soufre色,黃色,Noir色,黑色,Blue Jean,藍色,Brulee色,啡色,Brique,磚紅色,紅色,Rouge Garance色,Cigare色, 啡色,Noir,Cigare色,黑色,啡色,Gold色, 啡色,Rose tyrien色,桃紅色,Rouge Casaque色Bleu Thalassa色, 紅色, 藍色,Blue Jean色, 淺藍色,Pearl Grey色, 淺灰色,Rouge H色,Bleu Obscurs色,Vert Anglais色,紅色,藍色,綠色,Rose Lipstick色, 粉紅色,Rouge H色,酒紅色,Cafe色,Aubergine色,Bordeaux色,啡色,紫色,紫紅色,深藍色,Terre色, 啡色,Rouge Garance色, 紅色,Havane色, 啡色,Gold色,啡色,Blue Paradis色,藍色,紅色,Rouge H,Blue de Malte色,Blanc色,Mykonos色,白色,藍色,藍色,Blanc,Mykonos,藍色,Rose Jaipur色,玫瑰粉色,Rouge Pivoine色,粉紅色,Orange色,橙色,Rose scheherazade色,桃紅色,綠色,Vert Anglais,白色,白色,Red","hermes lindy":"Orange色, 橙色,Jaune Dor色,黃色,Sanguine, Rose Jaipur色,Gold色, 啡色,Ruby色, 紅色,Rouge Pivoine色,粉紅色,Rouge Casaque色,紅色,啡色,Gold,Rouge H,Moka,深啡色,Sanguine色, 橙色,Rubis色,紫紅色,Rose Tea色, 橙紅色,Blue Obcurs色, 深藍色,Bougainvillea色,Menthe, 綠色,Blue Jean色,藍色,Orange Poppy色, 橙色,Bougainvillier色, 紅色,Brulee色, Sienne色, 啡色, 紅色,Orange色,Flamingo色,粉橙色,紅色,Orange色,橙色,Gold色,啡色,Bleu Jeans色,藍色,粉橙色 , Flamingo色,21 Natuel,藍色,Malachite色,孔雀綠色,Sanguine色,橙色,Flamingo色,粉紅色,Bleu Jean色,淺藍色,Rouge Pivoine色,牡丹紅色,Bleu Jean色,藍色,Rouge Garance色,紅色,Bleu De Galice色,Gris Perle色,藍色,灰色,Rouge Pivoine色,紅色,Noir色,黑色,Red","hermes picotin":"Feu色,橙色","hermes roulis":"All","hermes toolbox":"Orange色, 橙色,Etoupe色,Kiwi色,灰色,青色,Feu色,Pain Depices色,橙色,Rouge Casaque色,紅色,Red,93 ORANGE","hermes victoria":"Blue Saphir色,Noir色,藍色,黑色","hermes virevolte":"All","other":"Jaune色, 黃色,Ecru色,Bleu Ocean色,米白色,藍色,Blanc色,Ecru色,白色,米色,Gris perle色,Potiron色,灰色,橙色,Bleu Ocean色,深藍色,Vermillon色,Noir色,紅色,黑色,Curry色, 啡色,Blood orange色,橙紅色,米色, 啡色,Terre色,啡色,Sienne色,Bleu Thalasa色,藍色,啡色,Indigo Blue色,深藍色,Preal Grey色, Curry色,Vert色,綠色,Blue Izmir色,Tosca色,紫色,Noir色,黑色,Malachite色,綠色,Noir色, 黑色,Brique色,磚紅色,橙色,金色,藍色,Etoupe色,大象灰色,NOIR,紅色,Green,桔色,89 NOIR"},"louis vuitton":{"louis vuitton alma":"粉紅色,裸色,酒紅色,紅色,橙色,靛蓝色,花蕊黄,芭蕾粉,热辣粉,蓝莓色,罂粟红,黑色,荧光粉色,奶茶色,棕色","louis vuitton artsy":"啡色,黑色,White,Brown","louis vuitton babylone":"All","louis vuitton bloomsbury":"啡色","louis vuitton brea":"深紫色","louis vuitton caissa":"RED","louis vuitton calvi":"白色","louis vuitton city steamer ":"白橘拼色,白绿拼色,宝石红,波尔多黑,褐色,黑蓝色,黑色,红色,灰黑色,深红色,棕黑拼色","louis vuitton cluny":"热辣粉,蓝莓色,芭蕾粉,奶茶色,黑色","louis vuitton delightful":"啡色","louis vuitton dora":"All","louis vuitton duomo":"BROWN","louis vuitton estrela":"啡色","louis vuitton explorer bag":"黑色","louis vuitton favorite":"Brown,棕色棋盘","louis vuitton lockit":"All","louis vuitton lockme":"宝石红","louis vuitton mabillon":"BROWN","louis vuitton montaigne":"All","louis vuitton neverfull":"啡色","louis vuitton noe":"黑色, 紅色,啡色,綠色,粉紅色,紅色,綠色,藍色,黃色,紅色,綠色,藍色,白色,多色,白色,棕色,老花","louis vuitton odeon":"啡色","louis vuitton olympe":"米色,灰色","louis vuitton pallas":"啡色,紫紅色,啡色,老花色","louis vuitton papillon":"啡色","louis vuitton petit noe":"All","louis vuitton petite malle":"All","louis vuitton phenix":"啡色,黑色","louis vuitton saint germain":"WHITE","louis vuitton siena":"啡色","louis vuitton siracusa":"白色","louis vuitton speedy":"咖色,藕粉色,葡萄红,樱桃红,黑色,灰色,象牙色,咖色棋盘格,白色棋盘格,棕棋格,米色","louis vuitton totally":"啡色,白色","louis vuitton tote":"All","louis vuitton trocadero":"啡色,啡色,黃色","louis vuitton twice":"All","louis vuitton twist":"黑色,白色,紅色,藍色","other":"黑色,啡色,杏色,紫紅色,紅色,白色,米色,銀色, 金色,粉紅色,白色,淺啡色,橙色,綠色, 深啡色,黃色,金色,白色,黃色,啡色, 金色, 銀色,深藍色,藍色,黃色,紫色,白色,彩色,灰土色,藍色,啡色, 黑色,深啡色,深綠色,啡色,米白色,綠色,白色,多色,粉紅色,銀灰色,黑色,多色,灰色,黑色, 彩色,淺紫色,灰藍色,淺灰色,酒紅色,淺藍色,米黃色,灰紫色,白色,啡色,多色,朱紅色,褐色,焦糖色,葡萄红,樱桃红,军绿色,Brown,深棕色，老花色,棕色,三色拼老花,BROWN,RED,WHITE,BROWN RED,BLACK,BROWN MONOGRAM,BLACK MONOGRAM,DARK BLUE"},"michael kors":{"other":"Black,藍色,啡色,黑色,紅色,黃色,米白色,粉紅色,淡粉色,深蓝色,粉色,金色,浅紫色,浅蓝色,蓝色,灰色,藏蓝色,咖啡色,白色,红色,大象灰,Red,Green,Blue,Pink,Orange,Multicolor,橘黄,亮粉色,黑色等,紫红色,西瓜红,淡金黄,黑色 枚红色 棕色,杏色,多色,浅咖啡,古典玫瑰色,綠, 紅,煤炭灰,棕灰,桔色,黑色。红色,黄色,银色,粉,黑,红,藏蓝,咖啡,沙色,珊瑚色,钢蓝色,珊瑚紅,深卡其色,红,棕,黑,红,浅蓝,黄,灰蓝,西瓜红,Black (Designer Colour),四色,浅灰色,深桔色,蜜桃色,多种颜色,桃红色,淡紫色,粉红玫瑰,裸粉,珊瑚红,天蓝色,桃粉色+橘粉色+红色,灰蓝色,电光蓝,粉玫瑰红色,淡红色,酒红色,果仁色,西柚粉色,光白,新藏蓝色,黄色,米白色,砖红色,梅子色,红白棕接色,裸粉色,粉红色,棕色,乳白色,拼色,青色,淀蓝色,葡萄柚粉红色,青瓷绿,黑色银铆钉,蓝黑,紫红,水泥灰,DRSE,ECR,BLK,卡其色,莫斯色,卡其棕色,海军蓝,砖红,紫,花瓣粉,深红色,蛇纹皮色,电蓝色,砖色,梅色,粉玫瑰色,蓝黑,珍珠灰,藏青色,浅棕色,青瓷色,深棕色,浅沙色,白色,粉色,深蓝,蓝灰色,浅绿,浅绿色,樱花粉,橘红色,电光蓝色,银白色,篮色,玫瑰粉、浅灰蓝,牡蛎色,郁金香粉,深绿色,深紫色,郁金香深粉色,红色,黑色,橘粉色,浅蓝,蓝,玫红色,西柚红色,灰,浅灰,黑,淡灰色,粉蓝色,玫瑰粉,泥灰色,珊瑚粉,珊瑚粉色,灰褐色,苔藓绿,珊瑚橘,梅红色,煤炭棕,煤渣灰,蓝色,桔粉,樱桃红色,樱桃红,暗牛仔色,橙色"},"miu miu":{"other":"綠色,ﾊﾟｰﾌﾟﾙ(MELA),啡色,杏色,白色,灰色,米色,紅色,黑色,桃紅色,深紅色,藍色,淺青色,橙色,卡其色,黃色,淺紫色,紫色,PINK,粉紅色,灰黑色,淺粉紅色,淺粉紅,Pink,Beige,深紫色,藍色,啡色,黑色,藍色,淺紅色,深藍色,Gray,淺黃色,Grey,灰藍色,粉色,裸粉色,大红,玫红,绿色,天蓝,灰蓝色,棕色,裸色,米紅色,白色,黑色,卡其,蓝黑拼色,红色,蓝色,多色,蓝白拼色,拼色,银色,天蓝色,樱桃红"},"prada":{"prada cuir":"All","prada double":"All","prada esplanade":"All","prada galleria":"All","prada gaufre":"All","prada inside":"All","prada lux":"All","prada soft":"All","other":"黑色、 紅色、 藍色,多色,淺啡色,啡色, 深藍色,Amaranto色, Nero色,銀色,黃色,橙色,藍色,粉藍色,黑色,灰色,啡色, 白色,紅色,紫色,綠色,藍色,白色,灰啡色,藍色,杏色,淺綠色,灰色,深紫色,深灰色,白色,啡色,裸色,啡色,黑色,綠色,粉紅色,深紅色,啡色,白色,橙紅色,紅色,白色,粉紅色,黃色,銀灰色,啡色,黃色,灰黑色,beige,米色,黑色,紫色,黑色,軍綠色,桃紅色,橙黃色,啡色,黑色,白色,桃粉紅色,牡丹粉色,藏蓝色,咖色,黑色等,蓝色,钴蓝色,宝石蓝,蓝色印花,蓝色等,浅褐色,红色,驼色,Ibisco (Designer Colour),粉红色,粉色,深蓝色,紫红色,Nero (Designer Colour),湖蓝色,玫粉色,肉桂棕,其他,银色,枚红色,枚红色等,拼色,橙色,军绿色,黑色，白色,焦糖棕,皇家蓝,肤色，滑石粉白,黑色，红色,浅粉色,藏青色,黄,酒红,黑红,浅蓝色,裸粉色,黑色白色,咖啡色,海蓝色"},"salvatore ferragamo":{"other":"白色,啡色,黑色,米色,藍色,粉紅色,黃色,紫色,黑,金,红色,多色,红色、黑色等,孔雀蓝色,深粉红色,粉色,银色,黑色、裸粉色等,Anemone (Designer Colour),黑色等,Mora (Designer Colour),其他,-,莓红色,水蓝色,灰色,樱花粉色,金色,蓝色,玫红色,深红色,黄色,白金色,绿色,深紫色,藏青色,枚红色,芭蕾粉,裸色,酒红色,藏蓝色,宝蓝色,深蓝色 紫红色 黑色,酒红色 桃红色,桃紅色,裸粉色,西瓜红,杏色,暗红色,深褐色,烟灰色,玫粉色,暗蓝色,玫瑰红,浅卡其色,深灰色,棕色,咖啡色,黑,栗棕,橙,天蓝色、紫色,棕红色,桃红色,粉红色,深粉色,紫红色,桃粉色"},"tiffany & co":{"other":"All"},"tory burch":{"other":"深藍色,米色,藍色,粉紅色,紫色,红色,豹纹,银色,黑白点,棕色,红,棕 肉,黑白棕拼色,灰色,蓝色,金色,黑色,Poppy Red (Designer Colour),邦迪蓝,法国灰色,牡丹红,深红色,粉色,砖红色,深紅紫,煤灰,皇家海军,火花金,梅红色,浅粉,玫红色"},"valentino":{"other":"桃紅色,桃紅色,酒紅色,黑色,啡紅色,酒紅色,米白色,裸色,粉紅色,黑色,深紅色,灰綠色,紫,啡色豹紋,灰色,綠色,藍色,紅色,淺紅色,粉紅色,軍綠色,灰色,螢光粉紅色,米色,绿色,黑,迷彩,迷彩色,混色,红色,粉蓝色,黄色,浅蓝色,杏灰混色,黑色,红色,深肤色,浅绿色,深绿色,杏色,粉色,紫色,浅粉色"},"yves saint laurent":{"other":"深啡色,啡色,深藍色,深灰色,紅色,黑色,杏色,黃色,紫色,黑色,啡色,深紅色,紅色,灰色,Brown,蓝色,其他,天蓝色,藏蓝色,粉色,黑色 绯红色,-,深玫红色,深红色,红色,粉红色,金色,深蓝色,桃红色,玫红色,泡泡糖玫红,深红,银色"}},"totes":{"balenciaga":{"balenciaga city":"Blue,Beige,Black,Grey,Red,Orange,Pink","balenciaga day":"All","balenciaga first":"All","balenciaga le dix soft":"All","balenciaga part time":"Black","balenciaga town":"All","balenciaga weekender":"All","balenciaga work":"沙色,Black","other":"綠色,白色,金色,藍色,紫色,啡色,紅色,綠色,化石灰,蓝色,胭脂红,浅灰蓝色,浅蓝色,黑色,深蓝色,棕色,红色,牛皮,黄色,浅绿色,灰色,深蓝,深灰色,貂米色,紫红色,栗子棕,果仁米色,紫紅,矢车菊蓝,绿色,黑色+红色,黑色+蓝色,多色,粉红色,石榴红,深渊蓝,云灰色,深咖啡,石化灰,深雪茄棕,深绿色,雪茄棕,银色,深褐色,糖果玫瑰粉,Black,GREY,Blue,RED,Pink,GRAY AND BLACK,LIGHT BLUE,DARK BLUE,Purple"},"bottega veneta":{"other":"米色,金色, 黃色,粉紅色, 灰色,橙色,黑色,金色,杏色,啡色,藍色,深藍色,粉綠色,黃色,紫色,啡色,淺藍色,米色,橄欖綠色,淺啡色,粉紅色,古銅色,墨綠色,黑色,灰色,桃紅色,綠色,白色,青绿色,粉红色,桔色,浅咖啡色,咖啡色,棕色,深咖色,蓝色,土黄色,红色,草绿色,紫色,砖红色,咖色,黄色,深红色,灰黑色,浅棕色,粉色,深薄荷绿,PURPLE BLUE,DARK BROWN,GREY,Blue,Purple,BROWN,DARK BLUE,Black,DARK SILVER,PINK GOLD,DARK RED,Pink,Green,BRONZE,DARK GREY"},"bulgari":{"other":"All"},"cartier":{"other":"啡色"},"celine":{"celine belt":"All","celine cabas":"藍色,啡色,烟灰色,灰褐色,胭脂粉","celine classic box":"All","celine luggage":"黑色,啡色,藍色,啡色, 啡紅色,橘紅色,啡色, 黑色,酒紅色,米色,啡色,黑色,灰白色,黃色,杏色,米白色,灰色,黑色,米色,橙色,藍色,黑色,藍色,杏色,灰色,多色,自然色,白色,淡粉色,海军蓝,浅卡其色,裸色,白色和洋红色,蓝绿色,矿石蓝,矿物色,海军蓝和黑色,奶白色,浅卡其色和奶白色,浅灰褐色,黑色和白色,矿石蓝和黑色,天然色和黑色,拼色,烟灰色,烟黑色","celine phantom":"All","celine ring":"All","celine tie":"All","celine trapeze":"白色,黑色,啡色,深藍色,白色,黑色,蓝绿色,青柠色,Black","celine trio":"All","other":"紫色,杏色,粉紅色,白色,紅色, 啡色, 白色,白色,啡色,黑色,深绿色,黑色,黑白拼色,黑色洋红色,金黄色,淡粉色,海洋蓝,柑橘黄,灰色,岩石色,黑色和本白色,咖啡色,红色,拼色,苔绿色,浅蓝色,黑蓝色,石英色,PURPLE , BROWN , BEIGE,LIGHT BLUE,BLACK,Orange,BLACK , BROWN,BROWN,RED,Blue,Gray , black , blue"},"chanel":{"chanel boy quilted flap":"All","chanel cerf tote":"暗粉紅色,黑色","chanel classic flap":"Black,LIGHT BLUE,BEIGE","chanel gst":"All","chanel medallion tote":"All","chanel pst":"All","chanel ptt":"All","chanel reissue":"All","other":"黑色,象牙白色,Peach,土灰色,紅色,米色,墨綠色,洋紅色,粉紅色, 黑色,啡黃色,裸色,金色,啡色,深啡色,深藍色,銀色,粉紅色,黑色,紫色,酒紅色,淺啡色,紅色, 深藍色,粉紅色,紅色,白色,黑色,紅色,啡綠色,白色,暗紅色,橙色,灰色,灰色, 白色,藍色,粉紅色, 白色, 黑色,橄欖綠色, 酒紅色,黑色,黃色,銅色,米色, 深藍色,黃色,淺藍色,Grey,Black,MULTI COLOR,Pink,RED,GREY,Blue,SILVER,BLACK , PURPLE,LIGHT PINK,BLACK,GREEN , GRAY,ETOUPE,SKY BLUE,PEARL LIGHT GREY,DARK GREY,BROWN,LAKE BLUE,BLUE,WHITE"},"chloe":{"chloe drew":"Black,RED,Pink,LIGHT BLUE,Yellow,Purple,Blue","chloe elsie":"All","chloe faye":"Black,DARK GREEN,GREY,YELLOW MUD,ORANGE-RED","chloe hudson":"GREY,Black,RED,Blue","chloe kurtis":"GREY","chloe lexa":"All","chloe marcie":"Black,GREY,Blue,RED,Purple","chloe milo":"All","chloe paraty":"杏色,淺啡色","other":"啡色,黑色,金色"},"christian dior":{"other":"深紅色,深藍色,淺藍色,紅色,黑色,橙黃色,淺紫色,粉紅色,天蓝色、浅蓝色、02P粉红,Pink,Yellow,Purple,RED,Red,LIGHT BLUE,Blue,Orange,FUSHIA , LIGHT PINK , ORANGE"},"coach":{"other":"米色,黑色,黑色,啡色,粉紅色,紫色,红色,Black,Brown,格纹黑色,卡其绿边,卡其棕色,藏青,黄白拼色,湖蓝色,草莓色,杏 桔 蓝,深棕色,粉红,玫红,白色,黑色 桔色,海军蓝,卡其,红色,卡其,棕色,咖啡,蓝色星星,棕色,黑 白 红 桔黄 沙棕,黑 红 桔黄 灰 白,蓝色,桔色,黑 沙 黄 蓝 紫红,粉色,紅色,海軍藍,馬鞍棕,黑色，烟黑色,卡其色,咖色,棕,玫粉色,粉 灰 白,玫红色,粉,黑,True Red (Designer Colour),牡丹红,大丽花色,灰色，卡其色,卡其色，红色,蔚蓝色,橘色,樱桃红,桔红色,水绿色,灰色,深褐色,黑灰色,黑咖色,淡绿色,玫瑰红,黑色,松石绿,深棕配黑色,卡其,棕色，卡其色,樱桃粉,酒红色,亚麻黄,鲜红色,紫红色,鲜红色,珊瑚橙,松石绿,鞍棕色,蓝灰色,卡其配红,米色白边,卡其棕,浅棕色,紫色,银灰色,灰黑色,赛车绿,蓝黑色,米色,裸色,黑棕色,黑色,配棕色边,拼色,青铜色,Surplus,青色,咖啡色,红醋栗,深红,棕色,铂金"},"designer brands":{"hermes birkin":"All","other":"Pink,Black"},"fendi":{"fendi 2 jours":"藍色","fendi 3 jours":"All","fendi baguette":"All","fendi by the way":"黑色,浅灰,粉蓝,黑色,银色,红色,浅灰色","fendi dotcom":"黑色","fendi peekaboo":"All","other":"深紅色,米色,黑色,粉紅色,黃色,淺藍色,白色,透明色,啡色,茶色,深天蓝,黄色,混色,多色,Nero (Designer Colour),Bubblegum (Designer Colour),蓝色,玫红色,红色,正红,碳灰色,棕色,青色,绿松石色,咖啡色,孔雀蓝,栗红色,碳灰,灰色,粉色,杏子,多色拼色,粉灰色,午夜蓝,石榴红,蓝,深绿色,绿蓝色,孔雀绿,浅灰色,紫色,灰褐色,深灰色,波尔多红,浅棕色,Pink,Black,RED,BLUE,BROWN,RED"},"givenchy":{"other":"Grey,红色,黑紅色,黑色,Red,Pink beige,米色,霓虹粉色,棕色,李子紫,牛津蓝,深红色,金色,赭石黄,玫红色,多色,黑,深棕色,海洋蓝,酒红色,黑,红色,酒红,RED,Blue,Pink,Orange,PURPLE,LIGHT BLUE,Black"},"gucci":{"other":"黑色,深啡色,黃色, 啡色,啡色,粉色,金啡色,黃色,粉紅色,深啡色,桃紅色,米色,啡色,藍色,淺啡色,深紅色,灰色,粉紅色,啡色,白色,藍色,藍色,啡色,杏色,金色,灰黑色,芙蓉红,红色,黑色拼芙蓉红,黑色拼白色,浅蓝色,米色,乌木色,深蓝色,糖果粉,米色,棕色,蓝色,Black,卡其色,浅咖啡色,咖啡,粉红色,红棕色,卡其配棕色,经典色,花色,浅粉色,米色，棕，檀木棕,多色,浅绿色,淡紫色,咖啡色,浅棕色,紫色,橙色,藏蓝色,茄紫色,淡蓝色,浅米色,粉紫色,黄色,深褐色,棕色,深咖色,米色,蓝色,粉红色,橙红色,褐色,浅咖色,橘色,蓝色印花,绿色,大红色,玫粉色,黑色,乌木色,印花,卡其拼棕色,藏蓝色、棕色,玫红色,粉色、黑色,印花色,樱花粉,橘黄色,拼色,深橘色,棕黑色拼接,玫瑰红,柠檬黄色,黑色拼色,RED,GOLD,Red,BLACK , BROWN,Pink,BROWN,Orange,Blue,RED , BROWN"},"hermes":{"hermes atlas":"All","hermes berline":"All","hermes birkin":"紅色,Noir色,黑色,Bombou色,Brique色,Turquoise Blue色,Blue Jean色, 藍色,Rouge Imerial,Rouge Garance,Sienne,Jaune色, 黃色,黃色,Lime,Orange色,Rose Tyrien色,Celeste色,Geranium, 红色,Apple Green色,Blue Jean色,Sienne色,深紅色,Capucine 色,Bleu Paradise色,Caramel色,啡色,Gold色, 啡色,Natural色,Bougainvillier色,粉紅色,Pearl Grey,Blue Marine色, 深藍色,多色,Terre色,啡色,Blue Aztec色,藍色,Blue Jean 藍色,Vert Veronese色 Gold色 軍綠色 啡色,藍色, 7B Turquoise,Blue Aztec色, 淺藍色,Gold, 金色,Rouge Pivoine色,Bleu Izmir色,藍色,Rouge Pivioine,紅色,綠色,Pelouse色,Natural Sable,黃色,Vert Bronze色, 深啡色,Bambou,綠色,Blue Atoll色, 淺藍色,紅色,Geranium色,Chocolat色,深啡色,Rouge Csaque色, 紅色,Orange色,橙色,Chocolat色,啡色,Tabac Camel色,啡色,Bougainvillier色, 紅色,Blue Depresse色, 深藍色,黑色,Chocolat色, Gold色, 深啡色, 啡色,Rouge H色, 深紅色,Etoupe色, 灰色,Orange色, 橙色,Bleu Paradis色,天藍色,Chocolat色,巧克力色,Turquoise色,淺藍色,Alezan色, 啡色,Blue Jean色,藍色,Rose Jaipur色,玫瑰粉色,Bleu Paradis色,Rose the laiton色,粉橙色,米色,Blanc色, 白色,紅色,Rose Jaipur,Grioret色,Graphite色,淺啡色,墨黑色,Rose Jaipur色,橙紅色,Ebene色,深啡色,Fauve色,啡色,Vert veronese色 ,Blanc色,橄欖綠色,白色,Grioret色,灰色,Rouge Pivoine色,紅色,Forest Green色,深綠色,Capucine色,深橙色,Rouge Tomate色,紅色,Capucine色,橘紅色,Orange poppy色,罌粟橙色,Tabac camel色,駱駝色,Blue Saint色,淺藍色,啡色,Bougain Viller色,磚紅色,Geranium色,紅色,Vert Olive色,橄欖綠色,Noisette色,啡色,Ocre色,啡色,Vert Anis色,青綠色,Natural色,啡色,深啡色,Crevette色, 粉紅色,Black,Pink,Red,Grey,Blue,RED,BEIGE,Orange,Green,GERANIUM,BROWN,DARK GREEN,GOLD,GREY,BOUGAINVILL, PARCHEMIN,CELADON,3P BLEU ATOLL,1Q ROSE CONFETTI , P9 ANEMONE,5K TANGERINE,2T BLEU PARADIS,7B TURQUOISE,54 GARANCE RED,89 NOIR","hermes bolide":"Rouge Casaque色,紅色,RED,Pink,GREY,GOLD,Black,Orange,2Z BLEU NUIT,3Z BLEU SAINT CYR,SWIFT (1 BLANC) , TOILE (89 NOIR),89 NOIR,3P BLEU ATOLL,58 PRUNE","hermes cabag":"All","hermes constance":"Blue,RED,BROWN,C9 PAPRIKA(FUR)","hermes double sens":"Rouge Pivioine,Rose Sakura,紅色,粉紅色,Menthe色,Bleu Thalasa色,7B,S7","hermes egee":"Blue,GREY","hermes evelyne":"BROWN,Black,Orange,RED","hermes garden party":"Curry,啡黃色,啡色,Gold,Bougainvillter色,Capucine色, 橙色,Ocre色, 啡色,Brique色,藍色,Blue Izmir,Rose Sakura,粉紅色,Turquoise色,水藍色,Rouge Imperial色,紅色,Rouge Venitienne色, 紅色,紅色,Bougainvillier,Rouge H色,深紅色,Etoupe色, 灰色,Rouge garance色,Noir色,紅色,黑色,Bleu Saphir色,寶藍色,Brique色,磚紅色,Gold色,啡色,Sienne色,深紅色,Noisette色,啡色,Rouge H色,酒紅色,Orange色,橙色,Gris tourterelle色,啡色,Cigare色,啡色,Tosca色,紫紅色,Cobalt色,藍色,Pink色,粉紅色,Red,GOLD,RED,Black,DARK RED,WHITE , ORANGE,LIGHT BLUE,BROWN,Blue,Yellow,3Q ROSE SAKURA , 2V ROUGE DUCHESSE,BEIGE , BLANC,9J FEU , 81 GRIS-BEIGE PTN,54,78,IVORY,89 NOIR","hermes halzan":"BROWN , ORANGE,Orange,RED,DARK GREY,BEIGE,Black,GOLD,46 EBENE","hermes harnais":"Beige","hermes herbag":"Orange色,Pink,RED,GOLD,BLUE,BROWN,BROWN,1L CACTUS , 27 NATURE,3Q,27 SAKURA,NATUREL,95 AZURE , NATURE,B5 34 RUBIS FAUVE SILVER","hermes jige":"RED,Pink","hermes jypsiere":"93 ORANGE,6W,81 MENTHE,GRIS","hermes kelly":"Fauve色, 啡色,Feu色,深橙色,Noir色,黑色,Blue Saint-Cyr色,湖藍色,Capucine色,橙色,Chocolat色,巧克力色,Orange色,橙色,Black,Blue,GREY,RED,GOLD,LIGHT BLUE,BROWN,DARK GREY,DARK BLUE,Pink,DARK GREEN,9J FEU,2R ROUGE PIVOINE,3L ROSE THE,1T VERT TITIEN,2T BLEU PARADIS,9T CAPUCINE SS,83 ORANGE","hermes lindy":"黑色,Blue,GOLD,LIGHT BLUE,Orange,77 BLEU IRIS,3Z BLEU SAINT CYR","hermes massai":"All","hermes medor":"RED","hermes picotin":"Rouge Duchesse色, Blue De Galice色, 紅色, 藍色,Colvert色, 藍色,Sienne色, 啡紅色,Blue Paradis色,淺藍色,Sienne色,深紅色,Parchemin,Cumin色,Rouge Casaque色,紅色,Rose Jaipur色,紅色,Bleu de galive色,藍色,Bleu Indigo色,深藍色,Noir色,黑色,Bougainvillier色,淺紅色,Bleu Jean色,淺藍色,Ultraviolet色,紫色,Gold色,啡色,Colvert色,深藍色,Blanc色,白色,Bubblegum pink色,糖果粉紅色,Bleu Jean色,藍色,Orange色,橙色,啡色,Brule色,Briqe色,深橙色,Rouge Indien色,淺粉紅色,Bambou色,綠色,Gold色,金色,Noir, 黑色,Yellow,Green,RED,ORANGE,RED,Blue,DARK BLUE,Orange,BROWN,55 36 ROUGE","hermes plume":"Fauve色,啡橙色,Rouge Casaque,紅色","hermes roulis":"RED,Blue","hermes toolbox":"9J,20 SWIFT 3P BLUE ATOLL","hermes victoria":"Rouge Casaque色, 紅色,Black,54,93 ORANGE","hermes virevolte":"All","other":"Blue.Jean色,Feu色,橙色,Rainsin色,Malachite 綠色,Craie, 淺灰色,多色,Rainsin色, 紫色,Pink,粉紅色,Alezan色, 深啡色,黑色,Marron色, 啡色,Aubergine色,深紫色,Etoupe色,啡色,Bleu Atoll色,藍綠色,Rough H色,啡紅色,Bleu Paon色,綠藍色,深藍色,Sienne色,啡紅色,Argile色,Ciel色,米色,淺藍綠色,Rouge Piment色,紅色,Bubblegum Pink色,粉紅色,橙色,藍色,Rose Sakura色,粉紅色,Etoupe色,灰色,Pain depices,橙色,Bleu Orage色,Blanc色,藍色,白色,Paille色,啡黃色,Ruby色, 紫紅色,Noir色,Ecru色,黑色,米色,Noir色,黑色,Crevette色,淺粉紅色,Bleu Atoll色,藍色,Bleu Aztec色,藍色,Tosca色,紫紅色,BROWN,Pink,Black,55 ROUGE H,RED,16 TAUPE,D5,4H CACAO"},"jaeger":{"other":"All"},"louis vuitton":{"louis vuitton alma":"啡色,白色,枚紅色,紅色,深藍色,橙色,粉紅色,黑色,Beige","louis vuitton ana":"All","louis vuitton artsy":"All","louis vuitton babylone":"All","louis vuitton bagatelle":"All","louis vuitton brea":"All","louis vuitton caissa":"All","louis vuitton capucines":"紅色","louis vuitton city steamer ":"All","louis vuitton cluny":"罂粟红","louis vuitton croisette":"白棋格","louis vuitton deesse":"All","louis vuitton doc":"All","louis vuitton dora":"All","louis vuitton duomo":"All","louis vuitton estrela":"All","louis vuitton eva":"粉紅色,紅色,啡色","louis vuitton greenwich":"BROWN","louis vuitton kimono":"All","louis vuitton lockit":"啡色,卡其色,銀色","louis vuitton lockme":"Black,黑色","louis vuitton louise":"All","louis vuitton majestueux tote":"All","louis vuitton marais":"啡色","louis vuitton marceau":"All","louis vuitton montaigne":"All","louis vuitton neverfull":"啡色,Brown,棕色,米色,BROWN MONOGRAM,WHITE","louis vuitton noe":"啡色","louis vuitton odeon":"All","louis vuitton olympe":"All","louis vuitton pallas":"BROWN,CHERRY","louis vuitton papillon":"啡色,金色","louis vuitton petite malle":"All","louis vuitton pont neuf":"黑色","louis vuitton retiro":"All","louis vuitton riviera":"WHITE","louis vuitton saint germain":"RED","louis vuitton sc bag":"All","louis vuitton siena":"BROWN","louis vuitton soufflot":"黑色","louis vuitton speedy":"啡色,橙色,綠色,白色,紅色,白色,白色,多色,藍色,紫色,啡色,紅色,黑色,Brown","louis vuitton sully":"All","louis vuitton totally":"Brown","louis vuitton tote":"Blue","louis vuitton tournon":"All","louis vuitton trocadero":"All","louis vuitton twist":"Black","louis vuitton volta":"All","other":"白色,啡色,紅色,藍色,多色,黑色,黃色,紅色,白色,桃紅色,酒紅色,藍色,黃色,酒紅色,黑色, 深紫色,紫色,金色,銀色,綠色,灰藍色,藍色,啡色,橙色,黑色,多色,米白色,米色,白色,多色,白色,彩色,綠色,多色,墨綠色,啡色,金色,啡色,黑色,深啡色,白色SUHALI,棕色,白棋格,老花色,Red,Purple,Black,BROWN,NOIR,RED,BLACK MONOGRAM"},"michael kors":{"other":"白色,藍色,銀色,白色,粉紅色,啡色,卡其色,深灰色,黃色,粉色,Black,Blue,Red,Green,Brown,蓝色,玫红色,多色，裸粉色女包五金件为金色，其余五金件为银色,卡其,银色,金色,黑色,棕色,海军蓝,灰色,藏蓝色,鋼鐵藍 (Steel Blue),珊瑚色,钢蓝色,樱桃红,珊瑚桔红,多色,深棕色,黑色、蓝色等,米色,红色,珊瑚红,煤炭咖啡,Silver (Designer Colour),橘红色,Luggage (Designer Colour),Steel Blue (Designer Colour),Dove (Designer Colour),珊瑚橘,红色,枚红色,珊瑚红色,鸽灰色,藏青色,葡萄柚粉,棕,裸粉,电光蓝,粉红玫瑰,褐色,浅粉色,奶咖色,灰蓝色,桃粉色,青色,葡萄柚色,粉红色,郁金香色,粉玫瑰红色,茶色,梅子色,青钢色,桃红色,浅樱花粉,水泥灰,砖红色,紫红,深蓝色,紫红色,灰,薄雾玫瑰,将军蓝,紫,青瓷色,炭灰色,上将蓝,淡绿,淡蓝色,卡其色,淡蓝色,卡其色,黑色,黑色,浅蓝色,玫瑰粉,樱花粉、灰蓝色、粉红色,桃红色、青瓷绿,黑色、水泥灰,莫斯色,蓝灰色,DUSTY ROSE 玫瑰色,玫瑰色,郁金香深粉,电光蓝,黑色,深棕,樱花粉,拼色,浅紫色,橘粉色,浅蓝色,西柚红色,柚粉色,淡紫色,葡萄柚粉红,驼色,浅棕色,浅绿色,淡绿色,青苔绿,灰绿色,苔藓绿,酒红色,Pink,LIGHT BLUE,LIGHT PURPLE"},"miu miu":{"other":"紫色,黑色,銀色,深紫色,啡色,深藍色,淺青色,深藍色,灰色,肉杏色,粉色,玫粉色,红色,深蓝色,红色，蓝色,杏色,藍色,玫红色,蓝色,橙色,翠绿色,多色,BLACK , PURPLE,DARK BLUE"},"prada":{"prada cuir":"All","prada double":"All","prada esplanade":"All","prada executive":"All","prada galleria":"All","prada gardener's":"All","prada gaufre":"All","prada inside":"All","prada lux":"All","prada soft":"All","prada twin pocket":"All","prada vitello diano":"All","other":"啡色,淺粉紅色,深藍色,紫色,深灰色,深綠色,黑色,淺啡色,灰黑色,黑色,藍色,桃紅色,黑色,桃紅色,黃色,古銅色,粉紅色,灰褐色,藍色,香檳色,綠色,啡色,灰色,紅色,米色,紅色,绿色,Blue,壤土黄,多色,牡丹粉色,粉色,矢车菊蓝色,黑色，玉兰粉,蓝色,多色等,黑色,蓝色,深蓝,藏蓝色,玫红色,天蓝色,红色,綠色,蓝色、红色等,湖蓝色,黄色等,深蓝色,黑色等,其他,-,棕色,亮银色,黑色,大红,松石绿,淡粉色,粉蓝色,米色,海蓝色,焦糖棕,大理石色,粉红色,大理石灰色,酒红色,浅蓝色,裸色,BLACK,RED,Yellow,Black,Pink,GRAY , BLACK,RED,Green,DARK BLUE,GREY,SILVER,LIGHT BLUE,BLACK"},"salvatore ferragamo":{"other":"淺銅色,黑色,浅棕色,棕色,拼色搭配,多色,Nero (Designer Colour),黑色等,粉紫,玫红色,内部2个拉链贴袋,浓汤色,蓝色,水蓝色,拼色,桃红色 黑色,其他,桃红色,覆盆子红,深蓝色,卡其色,酒红色,天蓝色、橘色、桃红色,黑灰色,红色"},"tiffany & co":{"other":"All"},"tory burch":{"other":"Multicolor,棕色,黑 蓝 红,黑色,海军蓝,黑,粉色,白色,咖色,Black (Designer Colour),Light Oak (Designer Colour),Vermillion (Designer Colour),Rose Sachet (Designer Colour),灰色,紫色,海军蓝色,美国,浅橡木粉,树皮棕，浅金色,蓝色,罂粟红"},"valentino":{"other":"淺啡色,啡紅色,深藍色,啡色,綠色,金色,白色,酒紅色,Pink,Black,浅绿色,黑色,彩色印花,迷彩色,桔色,粉色,粉红色,浅紫色,BLACK,RED,Blue,LIGHT BLUE,GREY,LIGHT PURPLE"},"yves saint laurent":{"other":"黑色,桃紅色,啡色,紫色,紅色,灰綠色,藍色,古銅色,金色,粉紅色,泥黃色,啡色,紅色,灰色,深灰色,Pink,黄色,橙色,其他,红色,海军蓝,印度粉,海蓝色,铁锈红,蓝色,黑色,红色,粉色,黑色白边,Blue,Yellow,Red,RED,GOLD,Purple,Black,LIGHT BLUE"}},"wallets and small accessories":{"balenciaga":{"balenciaga city":"All","balenciaga le dix soft":"All","other":"蓝色,Gris Fossile (Designer Colour),深灰色,藏青色,黑色,藏蓝色,绣球花粉,貂米色,黄色,灰褐色,浅棕色,天蓝色,土褐色,多色,灰绿色,紫红色,深蓝色,灰色,化石灰,Black"},"bottega veneta":{"other":"米色,白色,紅色,啡色,金色, 米色,綠色,灰藍色,灰粉紅色,紫色,橙色,桃紅色,深灰色,淺粉紅色,淺大象灰色,黑色,珍珠灰色,Brown,Red,Pink,Green,White,Grey,肉粉,深粉色,炭黑色,壤土红,红色,棕色,绿色,彩色,深蓝色,丁香紫,水墨黑,橘色,其他,卡其色,棕红色,灰色,浅棕色,绿色,军绿色,黑色拼色,碧玺蓝,蓝色,紫罗兰,淡粉色,驼色,深咖色,深蓝,藏蓝色,水墨灰,玫瑰金色,巧克力色,砖红色,深棕色,深蓝绿色,粉红色,咖色,咖啡色,粉色,裸粉色,Blue,GREY,BROWN,DARK RED,DARK BLUE,RED,DARK BROWN,Black,Purple,Orange,PURPLE"},"bulgari":{"other":"沙漠石英,PINK GOLD,SILVER"},"cartier":{"other":"酒紅色,紅色,GOLD,PINK GOLD,SILVER"},"celine":{"other":"藍色,浅卡其色,裸色,矿物色,黑色,胭脂粉,浅灰色,灰色,淡粉色,浅灰褐色,赤陶色和海军蓝,海洋蓝和黑色,罂粟红,黑色和矿物色,玉米黄,浅驼色,玉米色,芭蕾粉和烟黑色双色,浅驼色和瓷蓝色双色,芭蕾粉,瓷蓝色,黑色和玉米黄,本白色,中度蓝,午夜黑,辣椒红拼多色,烟绿色,烟绿色拼多色,淡灰色和深红色,黑色和本白色,黄褐色,大象灰,深蓝色,沙丘色,梅洛"},"chanel":{"chanel boy quilted flap":"Blue,Black","chanel pst":"All","chanel reissue":"All","other":"紅色,黑色,橙色,粉色,杏色,白色,灰色,紅色, 白色,墨綠色,多色,深藍色,銀色,白色,粉紅色,淺橙色,黃色,肉色,淺粉紅色,白色,藍色,酒紅色,藍色,黑色,黑色,白色,香檳金色,深紅色,桃紅色,深粉紅色,銀灰色,古銅色,深灰色,玫瑰金色,淺粉紅色,紫紅色,裸色,Red,Black,Blue,Purple,Pink,black,pink,橙红色,玫红内拼紫色,Yellow,DARK RED,GOLD,SILVER,LIGHT BLUE,GREEN,CHAMP GOLD,RED,CHERRY BLUE,CHERRY BLUE,CHERRY RED,GREEN MINT,LIGHT PURPLE,BLACK"},"chloe":{"chloe drew":"TAN","chloe faye":"Black","chloe hudson":"All","chloe marcie":"All","chloe paraty":"All","other":"啡色,深灰色,黑色,銀色,啡色, 淺藍色,浅灰,棉花糖粉,多色"},"christian dior":{"other":"深綠色,橙色,橙色,啡色,紫色,綠色,酒紅色,藍色,米色,黑色,其他,粉色、黑色,Pink"},"coach":{"other":"黑色,深藍色,啡色,桃紅色,藍色,黑色,啡色, 黑色,紅色,橙色,橙色,灰色,淺啡色,灰色,杏色,Black,Brown,棕色,红色,橘色,卡其紫色,灰棕色,棕,黑,黑 棕,彩色,午夜蓝,红,桃木色,奶茶色,红 绿 黄 粉 蓝,海军蓝,黑色,大丽花色,紫紅色,咖色,银色,蔚蓝色,蔚蓝拼色,玫红色,深蓝色,深棕色,深红色,咖啡色,牛皮,桔色,沙色,勃艮第酒红,粉笔白"},"designer brands":{"other":"All"},"fendi":{"fendi baguette":"All","fendi dotcom":"All","fendi peekaboo":"All","other":"啡色,藍色,深灰色,啡色,黑色,Pink,Multicolor,pink,宝蓝色,经典格纹,咖啡色,深咖啡色,玫红色,棕色,橙色,蓝边logo印花棕色,深粉LOGO印花,红边logo印花棕色,蓝紫,黑色,茶色,薰衣草紫,薄荷绿,咖色,拼色,黄色渐变,多色,本白色,绿色,橘色,玫红,枚红色,米黄色,花色,杏色,蓝色，黑色,深蓝色,tiffany蓝,亮玫红色,红色,蓝色,浅灰,黑色,电光蓝,黑色,蓝色,石墨,灰色,黄色,Black"},"givenchy":{"other":"Brown,黑色,其他,棕色,裸色"},"gucci":{"other":"粉紅色,黑色,銀色,芥辣黃色,啡色,黑色,黑色,多色,深藍色,暗玫紅色,紅色,黑色,白色,橙色,藍色,白色,綠色,紅色,灰色,黑色,紅色,啡色,紅色,紫紅色,銀色,紫色,藍色,米色,紅色,紫色,銀色,綠色,綠色,黑色,香檳金,棕色,拼色红盖,红色,拼色,Black,Brown,Blue,Pink,Multicolor,褐色,淡粉色,灰蓝色,深蓝色,浅咖色,黑色配红绿条纹,绿色,咖啡色,多色,樱花粉色,粉色,蓝色,黄色,卡其配橘红色,卡其配蓝色,深棕色,米色,裸色,浅棕色,玫紫色,乌木色,其他,卡其色,深绿色,姜黄色,蓝色+乌木色,橘黄色,花色,棕红色,橘红色,玫红色,黄褐色,浅紫色,暗红色,米色,蓝色,金色,深蓝,深粉红色,橘色 紫红色 黑色,卡其拼黑色,咖色,脸型刺绣,藏青色+奶白色+深红色,粉红色,紫色,粉红色,黑色,紫红色,玫粉色,深粉色,胭脂红,印花,米色,乌木色,红色+藏青色,黑色、棕色,黑色、粉色,黑色、粉色、红色,绿色、红色、紫色、粉色、裸粉色, 粉紅色,卡其,棕,黑色、深褐色,黑,橙黄色,橘色,藏蓝色,橙红色,香槟金色,卡其色,绿色,经典色,芙蓉红,Red,BROWN,GREY,Green,Purple,GRAY , BLACK,PURPLE,Orange,RED,DARK BLUE,LIGHT PURPLE,GOLD,LIGHT BLUE,SILVER,BLUE,RED,BROWN,GREY,RED,BLUE,BLACK , BROWN,GREY,PINK,BLUE,PINK,LIGHT BLUE,PURPLE,ORANGE-RED,WHITE,BLUE,BLACK,PINK,YELLOW,BLACK"},"hermes":{"hermes azap":"Flamingo,粉色,Braise , 紅色,Mykonos,Orange,橙色,Blue Jean色,粉紅色,Caramel色,啡色","hermes bearn":"Colvert色,藍色,Rose Tyrien,Rose Confetti,粉紅色,紅色,Geranium色,Cumin色,Rose Sakura色, 粉紅色,Rose Dragee, 粉紅色,Blue Paon色, 藍綠色,Rose Tyrien色, White色, 粉紅色, 白色,Rose Lipstick色,粉紅色,Orange色,橙色,藍色,Rouge Casaque色,紅色,Soufre色,黃色,Bougainvillier色,紅色,Rose scheherazade色,紫紅色,Noir色,黑色,Rose Tyrien色,粉紅色,Rose lipstick色,Rouge H色,粉紅色,紅色,NAVY BLUE色,Etoupe色,啡色,Red,Yellow,Blue,Pink,Green,LIGHT BLUE,RED","hermes bolide":"Pumice gray色,灰褐色","hermes constance":"Malachite色, 深綠色,紅色,Bleu Saphir色,藍色,Lagon色,Lichen色,淺藍色,橄欖綠色,Blue,Green,BROWN,RED","hermes convoyeur":"All","hermes dogon":"Anemone, 紫色,Anis Green,綠色,Brique色,Gold色,Blue Atoll色,淺藍色,粉紅色,灰色,Blue,Black,Green,RED,GOLD,DARK BLUE,Pink,PINK,ORANGE,Purple,P9 ANEMONE,7B,7T BLEU ELECTRIQUE","hermes evelyne":"Ultraviolet色,Pink,Yellow","hermes kelly":"Bamboo色,Blue Izmir色, 海藍色,Bougainvillier, 紅色,Vert Gris色 灰色,Ruby色,Blue Jean色, 淺藍色,B5色,Ruby,枚紅色,Vert anis色,青綠色,Vert色,深綠色,Aubergine色,紫色,Turquoise色,藍色,Bleu De Galice色,藍色,Rouge pivoine色,Gris elephant色,牡丹紅色,啡色,Rubis色,紅色,Etoupe色,啡色,Pink,Green,Blue,GOLD,GOLD,BLACK,Black,GOLD,BLUE,BEIGE,RED","hermes remix":"Multicolor","other":"黑色,啡色,紅色,黑色,磚紅色,Turquoise Blue色,橙色,綠色,青色,綠色,橙色,Blue Electric藍色,Noir黑色,橙色,藍色,桃紅色,Cactus色,Taupe色,綠色,灰色,Blue Jeans, 藍色, 黑色,紅色,綠色,藍色,Orange色,橙色,深藍色, 黃色,綠色,紫紅色,藍色,紫紅色,紅色,白色,黑色,海藍色,紅色,深粉紅色,藍色, 紅色, 綠色,橙色,灰色,黃色,紅色,綠色,藍色,綠色,Anemone purple色,藍色,Vermillon色,紅色,Bleu Hydra色,Violet色,深紫色,Blue Electric色, 電光藍色,Rouge Casaque色,紅色,紫色,粉紅色,淺藍色,黑色,藍綠色,白色,Bleu Paradis色,藍色,Rose Shocking色,白色,藍色,黃色 ,藍色,Tangerine色,Gris Elephant色,淺橙色,淺啡色,彩色,淺黃色,米色,粉紅色,灰色,紅色,紅色,深粉紅色,Bambou色,綠色,Orange色,Vert Cru色,橙色,青綠色,紅色,Vermillon色,紫色,綠色,淺藍色,紫色,泥黃色,藍色,黃色,綠色,淺藍色,深粉紅色,灰色,綠色,黑色,粉紅色,淺藍色,Cactus色,白色,多色,Rough H色, 深紅色,Blue Tarasa色, 深藍色,Noir色, 黑色,Rose eglantine色,粉紅色,Rose Lipstick色,粉紅色,橙色,黃色,藍色,灰色,淺紫色,黃色,灰色,橙色,紅色,黑色,Noir色,Gold色,啡色,橙色,啡色,深啡色,粉紅色,橙色,藍色,紅色,粉紅色,粉紅色,紅色,橙色,白色,粉紫色,薄荷綠色,粉紅色,藍色,白色,藍色,粉紅色,紫色,紫色,橙色,綠色,橙色,Etoupe色,灰色,紅色,白色,橙色,多色,藍色,多色,綠色,紫色,多色,黃色,多色,紅色,黃色,多色,粉紅色,綠色,紅色,藍色,Bleu Aztec色,綠色,黃色,綠色,啡色,橙色,白色,粉紅色,黃色,藍色,淺紫色,紅色,紫紅色,粉紅色,粉紅色,紅色,灰色,紫色,橙色,Rose Azalee色,粉紅色,Noir色,Rouge H色,Jaune色,Yellow,Blue,Brown,Red,Purple,Black,White,Pink,Grey,Multicolor,灰色,黄色,Orange,BROWN,RED,BLANC,Green,CELADON,SILVER,GOLD,PINK GOLD,ORANGE,APPLE GREEN,LIGHT PURPLE,DARK RED,DARK BLUE,BLUE,ORANGE,LIGHT BLUE,ORANGE,RED,ORANGE,BLUE,YELLOW,GREY,BLACK,SILVER,BROWN,GREY,BLACK,ORANGE,YELLOW CURRY,9H SOLEIL,8F ETAIN"},"louis vuitton":{"louis vuitton ana":"Brown","louis vuitton capucines":"All","louis vuitton croisette":"粉紅色","louis vuitton eva":"All","louis vuitton kimono":"All","louis vuitton montaigne":"All","louis vuitton neverfull":"All","louis vuitton pallas":"拼色","louis vuitton papillon":"All","louis vuitton pochette accessoires":"All","louis vuitton pochette mask":"All","louis vuitton rossmore":"All","louis vuitton segur":"All","louis vuitton speedy":"All","louis vuitton twist":"白色,多色","louis vuitton venus":"啡色,紅色","louis vuitton vivienne lv":"All","other":"紅色,灰藍色,白色,紅色+淺紅色,藍色,黑色,啡色,黃色,銀色,深紅色,淺紅色,米色,粉紅色,紫色,黃色,米白,啡色,紫色,黑色,黃色,粉紅色,金色,藍色,啡色,白色,多色,啡色,金色,銀灰色,深藍色,綠色,白色,粉紅色,裸色,米白色,金色,玫粉色,蓝色,红色,White,Black,Brown,Grey,老花色,灰色,拼色,棕色,樱桃红,黑色老花,黑色老花色,灰棋格,黑老花,黑灰色,蓝棋格,BROWN,LIGHT PURPLE,Blue,Purple,GREY,RED,DARK BLUE,BLANC,Pink,Red,BLACK,MULTICOLORE,BROWN , WINE RED,BLACK MONOGRAM,BROWN MONOGRAM,BROWN , PINK,BEIGE"},"michael kors":{"other":"藍色,黑色,White,Green,Red,Black,Brown,Blue,Pink,黑色 蓝色 粉色 棕色,藏青色,淡紫色,奶白色,浅灰色,青瓷色,珊瑚红,深棕色,桃粉色,天蓝色,西瓜红,浅蓝色,LIGHT BLUE"},"miu miu":{"other":"紫色,粉紅色,粉紫色,灰色,桃紅色,紅色,金色,啡色,黑色,紅色,藍色,红色,粉色,大红,天蓝,蓝色,Orchidea (Designer Colour),Gemma (Designer Colour),玫瑰粉,粉红色,银色,青瓷色,绿色,孔雀蓝,黑色，铁矿黄,深咖色,宝蓝色,酒红色,深樱桃红,多色"},"prada":{"prada cuir":"拼色","prada galleria":"黑色","prada lux":"All","prada soft":"黑色","other":"粉紅色,黑色,電光紫色,橙色,灰色,水藍色,藍色,深粉紅色,金色,黑色,藍色,灰色,紫色,Brown,Blue,Pink,深棕色,深蓝色,卡其色,多色,黑色等,藏蓝色,粉色,玫红色,天蓝色,黄色,咖色,红色,蓝色,黑色、橘色等,钴蓝色,棕色,真皮,粉红色,杏色,黑色 粉红色,杏色 紫红色,粉色 金色,蓝色 金色,黑色 金色,咖啡色,银灰色,蓝色等,黑,其他,-,松石蓝,粉红,淡蓝色,裸色,矢车菊蓝,豆沙色,波罗的海蓝色,黑色金标,牡丹粉,海蓝色,桃红色,银色,藏青色,橘色,Orange,BROWN,Purple,LIGHT BLUE,Black,RED,Red,SILVER,GOLD,GREY,DARK BLUE"},"salvatore ferragamo":{"other":"咖色,褐色,紫红,黑色,红色,裸色,橘黄色,粉色,浅蓝色,多色可选,棕色,深粉红,多色,粉紫,蓝色,紫色,拼色,黄色,玫红色,白色,秋牡丹粉，棉花糖粉,浅咖啡色,裸色等,深褐色,裸色、蓝色等,其他,莓红色,橙色,香芋紫色,Rosso (Designer Colour),深咖啡色,粉红色,藕粉色,水蓝色,芭蕾粉,樱花粉色,绿色,灰绿色,黑色 深蓝色,深灰色 粉色,藏蓝色 黑色,深蓝色 黑色,深蓝色 深咖色 黑色,红色 粉色,粉紫色,红棕色,咖色蓝色拼色,深蓝色,黑白灰拼色,彩色,灰色,深棕色,红色、黑色等,紫色、蓝色等,花色,肉色,黑,深酒红色,沙色,裸粉色,桃红色,卡其色,烟灰色,浅粉红色,巧克力色,神酒红色,藏蓝色,酒红色,-,太平洋蓝,BEIGE"},"tiffany & co":{"other":"All"},"tory burch":{"other":"Brown,Black,棕色,绿色,蓝色,枚红,黑色,红色,铁锈红"},"valentino":{"other":"黑色,枚红色,红色,藍色,橙红色,黑色漆皮,浅紫色,LIGHT PURPLE"},"yves saint laurent":{"other":"粉紅色,深藍色,綠色,白色,咖啡色,黑色,其他,驼色,藏蓝色,藏蓝色 深咖色 黑色,粉色 黑色 杏色,深酒红 深灰色,黑色白边,桃红色,红色,多色花纹,迷彩,黑色印花,深海洋蓝"}},"wrist watches":{"audemars piguet":{"other":"黃金,銀色, 深藍色,金色,銀色,藍色"},"balenciaga":{"balenciaga city":"All","balenciaga day":"All","balenciaga work":"All","other":""},"bottega veneta":{"other":"All"},"breitling":{"other":"藍色,銀色,白色,黑色"},"bulgari":{"other":"銀色, 黑色,黑色,銀色,銀色,黑色,白色,黑色,灰色,紅色,金色,白金,銀色,紅色,銀色,金色,黑色,白色,黃色,銀色,金色,面盤,黑色 錶帶"},"cartier":{"other":"銀色, 深粉紅色,金色,啡色,銀色, 黑色,金色,銀色,黑色,銀色,深啡色,銀色, 米色,銀色,金色,銀色,紫色,黑色,金色,銀色,金色,黑色,香檳金色,粉紅色,銀色,白色,金色,銀色,黑色,銀色,金色,黑色,黑色,黑色,白色,銀色, 白色"},"celine":{"celine trapeze":"All"},"chanel":{"other":"黑色,銀色,黑色,白色,銀色, 黑色,黑色,銀色,金色,黑色,金色, 黑色,銀色,黑色,白色,銀色"},"christian dior":{"other":"黑色,金色,銀色"},"coach":{"other":"銀色,黑色"},"fendi":{"fendi baguette":"All","other":"啡色,白色,銀色"},"franck muller":{"other":"金色,藍色,銀色,黑色,銀色,藍色,銀色, 杏色,銀色,白色,啡色"},"gucci":{"other":"All"},"hermes":{"hermes birkin":"All","hermes kelly":"啡色,黑色,銀色,金色, 黑色,金色, 紅色,金色, 白色, 紅色","hermes medor":"淺啡色, 金色","other":"金色,啡色,銀色,紅色,橙色,金色,銀色,淺藍色,紅色,金色,黑色"},"iwc":{"other":"All"},"jaeger":{"other":"All"},"louis vuitton":{"louis vuitton alma":"All","louis vuitton lockit":"All","louis vuitton montaigne":"All","louis vuitton speedy":"銀色,深啡色","other":"紅色, 金色,銀色,藍色,粉紅色,紅色,黃金,銀色,啡色,白色,紅色,啡色,銀色"},"michael kors":{"other":"金色, 黑色,金色"},"omega":{"omega constellation":"銀色,銀色,金色,金色, 銀色, 白色,銀色, 粉紅色","omega de ville":"銀色,面盤,黑色 錶帶,銀色","omega ladymatic":"All","omega seamaster":"銀色,藍色,銀色,銀色,黑色","omega speedmaster":"銀色,黑色,銀色,白色,銀色,藍色","other":"銀色"},"panerai":{"panerai luminor":"黑色, 銀色,黑色,啡色","panerai mare nostrum":"All","panerai marina militare":"All"},"patek philippe":{"other":"All"},"prada":{"prada lux":"All","other":""},"rolex":{"rolex air king":"藍色,銀色","rolex cellini":"All","rolex cosmograph":"All","rolex date":"銀色,金色,銀色, 金色,黃金,銀色, 啡色,銀色,黑色,金色, 銀色,銀色,銀色,綠色,黃金色,黑色,玫瑰金色,金色,金色,銀色,粉紅色,銀色,黃金,銀色,金色,藍色,銀色,白色,面盤,金色 錶帶,金色+銀色,玫瑰金色, 黑色","rolex datejust":"不鏽鋼,啡色,銀色","rolex daytona":"金色,銀色,白色,銀色","rolex explorer":"銀色,黑色,銀色","rolex gmt master":"銀色,黑色","rolex milgauss":"銀色,灰色,綠色","rolex oyster perpetual":"啡色,銀色, 藍色,金色","rolex sea dweller":"All","rolex submariner":"All","rolex yachtmaster":"All","other":"香檳金色, 銀色,銀色"},"tiffany & co":{"other":"銀色, 白色,金色"},"tissot":{"other":"金色,銀色"},"valentino":{"other":"All"}}}


